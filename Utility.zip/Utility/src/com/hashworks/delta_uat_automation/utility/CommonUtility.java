package com.hashworks.delta_uat_automation.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;

public class CommonUtility {

	static Properties obj_property;
	 
	
	
	//Generic method
	//This method is developed to handle any changes with respect to locator
	//This method receives the object property in the form "loactortype:locatorValue" and returns appropriate locator 	
	public static By getLocator(String objectProperty) throws Exception {
        try{
	    //load the property file 
		obj_property=CommonUtility.loadPropertyFile();
		
		String[] locatorArray=objectProperty.split("%");
		
        String locatorType = locatorArray[0];
        String locatorValue =locatorArray[1];
        //Accessing locators name through property file 
        //and this method will Return a instance of By class based on type of locator
          if(locatorType.toLowerCase().equals(obj_property.getProperty("locatortype1")))
                return By.id(locatorValue);
          else if(locatorType.toLowerCase().equals(obj_property.getProperty("locatortype2")))
                return By.name(locatorValue);
          else if((locatorType.toLowerCase().equals(obj_property.getProperty("locatortype3"))))
                return By.className(locatorValue);
          else if((locatorType.toLowerCase().equals(obj_property.getProperty("locatortype4"))))
                return By.tagName(locatorValue);
          else if((locatorType.toLowerCase().equals(obj_property.getProperty("locatortype5"))))
                return By.linkText(locatorValue);
          else if(locatorType.toLowerCase().equals(obj_property.getProperty("locatortype6")))
                return By.partialLinkText(locatorValue);
          else if((locatorType.toLowerCase().equals(obj_property.getProperty("locatortype7"))))
                return By.cssSelector(locatorValue);
          else if(locatorType.toLowerCase().equals(obj_property.getProperty("locatortype8")))
                return By.xpath(locatorValue);
          else
                  throw new Exception("Locator type '" + locatorType + "' not defined!!");
        }
	catch(Exception e){
		System.out.println("Caught exception while executing getLocator method from utility"+e);
		e.printStackTrace();
		return null;
	}
	}

	
	//this method will load property file 
        public static Properties loadPropertyFile() throws IOException
        {
        	obj_property=new Properties();
        	FileInputStream propertyFilePath=new FileInputStream("Configuration/Config.properties");
   		    obj_property.load(propertyFilePath);
   		    return obj_property;
        }

}
