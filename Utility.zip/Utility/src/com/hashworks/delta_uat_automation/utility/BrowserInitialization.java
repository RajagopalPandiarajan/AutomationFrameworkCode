package com.hashworks.delta_uat_automation.utility;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.hashworks.delta_uat_automation.utility.CommonUtility;



public class BrowserInitialization {


public WebDriver driver=null;	
	
Properties obj_property;

	//this method will execute first in the entire script

	
	
	@BeforeClass
	public  void setBrowser() throws IOException {
		
	//load the property file	
    obj_property=CommonUtility.loadPropertyFile();
 
    //Accessing chrome driver property through property file
	System.setProperty(obj_property.getProperty("setPropertyArg1ForChrome"), obj_property.getProperty("chromeExePath"));
	
	/*//open chrome driver
	driver = new ChromeDriver();*/
	//maximize browser window
	
	
	DesiredCapabilities obj_DesiredCapabilities = DesiredCapabilities.internetExplorer();
	
	obj_DesiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true); 
	obj_DesiredCapabilities.setCapability("nativeEvents", false);    
	obj_DesiredCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
	obj_DesiredCapabilities.setCapability("ignoreProtectedModeSettings", true);
	obj_DesiredCapabilities.setCapability("disable-popup-blocking", true);
	obj_DesiredCapabilities.setCapability("enablePersistentHover", true);
	
	driver = new InternetExplorerDriver(obj_DesiredCapabilities);
	
	driver.manage().window().maximize();
	//enter url
	driver.get(obj_property.getProperty("url"));
	
	//driver.get("C:/login.html");
	}


	//close the browser
	@AfterSuite
	public void terminateSettings()
	{
		driver.quit();
	}

}
