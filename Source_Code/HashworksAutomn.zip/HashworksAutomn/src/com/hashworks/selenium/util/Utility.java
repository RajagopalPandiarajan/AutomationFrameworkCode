/**
 **************************************************************
 * Author           : Kailash_Swain
 * Created          : NOV 11, 2016 - 11:34:35 AM
 * 
 **************************************************************
 * <copyright file= Utility.java company='Dell'>
 * Copyright (c) Dell 2015. All rights reserved.
 * </copyright>
 * <summary>Provide summary of Utility class here.</summary>
 **************************************************************
 */

package com.hashworks.selenium.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

/**
 * The Class Utility.
 */
public class Utility {

	static ArrayList<String> jarlist = new ArrayList<String>();

	static Properties prop = new Properties();
	/**
	 * Read file as string.
	 * 
	 * @param inputStream
	 *            the input stream
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String readFileAsString(InputStream inputStream) throws java.io.IOException {
		byte[] buffer = new byte[(int) inputStream.available()];
		BufferedInputStream stream = null;
		try {
			stream = new BufferedInputStream(inputStream);
			stream.read(buffer);
			if (stream != null)
				try {
					stream.close();
				} catch (IOException ignored) {
				}
		} catch (IOException ignored) {
			System.out.println("File not found or invalid path.");
		}
		return new String(buffer);
	}
	
	/***
	 * This method will be used to updateClasspath - Method to update/modify the .classpath file
	 */
	public static void updateClasspath(String _classpathloc) {
		
		ArrayList<String> jarList = getJarList();
		String classpathLoc = (_classpathloc.replace("/", "\\") + "\\.classpath");
		File file = new File(classpathLoc);
		BufferedWriter out = null;
		ArrayList<String> al = new ArrayList<String>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
			String line;

			while ((line = br.readLine()) != null) {
				if (line.contains("JRE_LIB")!=true)
				{
				al.add(line);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		int rows = jarList.size();
		for (int j = 0; j < rows; j++) {
			int temprows = al.size();
			boolean duplicate = false;
			for (int k = 0; k < temprows; k++) {
				if (al.get(k).contains(jarList.get(j))) {
					duplicate = true;
					System.out.println("Duplicate Entry : " + jarList.get(j) + "\n");
				}
			}
			if (duplicate == false) {
				al.add(temprows - 1, "\t" + "<classpathentry kind=\"lib\" path=\"C:/SeleniumJars/lib/" + jarList.get(j) + "\"/>");
			}
		}

		try {
			out = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < al.size(); i++) {
				out.write(al.get(i) + "\r\n");
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/***
	 * This method will be used to get the jar list from the properties file
	 * @param scrType
	 * @return
	 */
	private static ArrayList<String> getJarList() {

		InputStream inputStream = Utility.class.getResourceAsStream("/jarlist.properties");
		try {
			prop.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
		StringBuilder commonfileFromProperties = new StringBuilder(prop.getProperty("selenium"));
		String[] commonfileList = commonfileFromProperties.toString().split(",");
		StringBuilder utilityfileFromProperties = new StringBuilder(prop.getProperty("utility"));
		String[] utilityfileList = utilityfileFromProperties.toString().split(",");

		Collections.addAll(jarlist, commonfileList);
		Collections.addAll(jarlist, utilityfileList);
		return jarlist;
	}

}
