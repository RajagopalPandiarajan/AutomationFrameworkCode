package com.hashworks.selenium.sdet;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;

import com.hashworks.selenium.util.Utility;

/***
 * 
 * This class creates new work flow page 
 */

public class WorkFlowPage extends WizardNewFileCreationPage {

	public WorkFlowPage(IStructuredSelection selection) {
		super("Custom Plug-in Work Flow Wizard", selection);

		setTitle("Work Flow Wizard");
		setDescription("Create a Work Flow");
		setFileExtension("java");
	}

	@Override
	protected InputStream getInitialContents() {
		InputStream inputStream = null;
		try {
			String className = this.getFileName().split("\\.")[0];
			String fullPackageName = this.getContainerFullPath().toString().replace("/", ".");
			String [] packageName= fullPackageName.split("src");
			String str = "";
			if (packageName.length == 2) {
				str = "package " + packageName[1].substring(1)
				+ ";\n";
			} 
			InputStream in = PagePage.class.getResourceAsStream("/resources/classtemplate/SamplePage.txt");
			str = str + Utility.readFileAsString(in).replaceAll("SamplePage", className);			
			inputStream = new ByteArrayInputStream(str.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return inputStream;
	}
}
