package com.hashworks.selenium.sdet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.launching.JavaRuntime;
import org.eclipse.jdt.ui.wizards.JavaCapabilityConfigurationPage;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.WizardNewProjectCreationPage;
import org.eclipse.ui.wizards.newresource.BasicNewProjectResourceWizard;
import org.eclipse.ui.wizards.newresource.BasicNewResourceWizard;

import com.hashworks.selenium.util.Utility;

/***
 *
 *
 *         This class creates new project Template
 */

@SuppressWarnings("deprecation")
public class Project extends Wizard implements INewWizard {

	private WizardNewProjectCreationPage fMainPage;
	private JavaCapabilityConfigurationPage fJavaPage;
	private IConfigurationElement fConfigElement;
	private IWorkbench fWorkbench;
	private IProject project;
	private IFolder folder;

	public Project() {		
		setWindowTitle("New Hashworks Selenium Project");
	}

	public void setInitializationData(IConfigurationElement cfig,
			String propertyName, Object data) {
		fConfigElement = cfig;
	}

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		fWorkbench = workbench;
	}

	public void addPages() {
		super.addPages();
		fMainPage = new WizardNewProjectCreationPage("New Hashworks Selenium Project");
		fMainPage.setTitle("New");
		fMainPage.setDescription("Create a New Hashworks Selenium Project.");

		addPage(fMainPage);

		// the Java build path configuration page
		fJavaPage = new JavaCapabilityConfigurationPage() {
			public void setVisible(boolean visible) {
				// need to override to react to changes on first page
				updatePage();
				super.setVisible(visible);
			}
		};
		addPage(fJavaPage);
	}

	private void updatePage() {
		try {
			IJavaProject jproject = JavaCore.create(fMainPage.getProjectHandle());
			if (!jproject.equals(fJavaPage.getJavaProject())) {
				IPath srcLocation = jproject.getPath().append("src");
				IClasspathEntry[] buildPath = {
						JavaCore.newSourceEntry(srcLocation),
						JavaRuntime.getDefaultJREContainerEntry(),
						JavaRuntime.getJREVariableEntry() };
				IPath outputLocation = jproject.getPath().append("bin");
				// create folder by using resources package
				folder = project.getFolder("src");
				folder.create(true, true, null);				
				IPackageFragmentRoot srcFolder = jproject.getPackageFragmentRoot(folder);
				//create lib folder
				srcFolder.createPackageFragment("lib", true, null);
				//create package fragment
				srcFolder.createPackageFragment("com.hashworks."+project.getName().toLowerCase() +".pages", true, null);
				srcFolder.createPackageFragment("com.hashworks."+project.getName().toLowerCase() +".workflows", true, null);
				srcFolder.createPackageFragment("com.hashworks."+project.getName().toLowerCase() +".testcases", true, null);
				fJavaPage.init(jproject, outputLocation, buildPath, false);
				IFile file = project.getFile(new Path(folder.getName() + "/Config.properties"));
				createFile(file);
			}
		} catch (JavaModelException e) {
			e.printStackTrace();
		} catch (CoreException e) {
			e.printStackTrace();
		}
	}

	private void finishPage(IProgressMonitor monitor)
			throws InterruptedException, CoreException {
		if (monitor == null) {
			monitor = new NullProgressMonitor();
		}
		try {
			monitor.beginTask("Creating Hashworks Selenium Project...", 3); // 3 steps

			project = fMainPage.getProjectHandle();
			IPath locationPath = fMainPage.getLocationPath();

			// create the project
			IProjectDescription desc = project.getWorkspace()
					.newProjectDescription(project.getName());
			if (!fMainPage.useDefaults()) {
				desc.setLocation(locationPath);
			}
			project.create(desc, new SubProgressMonitor(monitor, 1));
			project.open(new SubProgressMonitor(monitor, 1));

			updatePage();
			fJavaPage.configureJavaProject(new SubProgressMonitor(monitor, 1));

			// change to the perspective specified in the plugin.xml
			BasicNewProjectResourceWizard.updatePerspective(fConfigElement);
			BasicNewResourceWizard.selectAndReveal(project, fWorkbench.getActiveWorkbenchWindow());

		} finally {
			monitor.done();
		}
	}

	@Override
	public boolean performFinish() {
		WorkspaceModifyOperation op = new WorkspaceModifyOperation() {
			protected void execute(IProgressMonitor monitor)
					throws CoreException, InvocationTargetException, InterruptedException {
				finishPage(monitor);
			}
		};
		try {
			getContainer().run(false, true, op);
			setTestNGClassPath();
			Utility.updateClasspath(folder.getParent().getLocation().toString());
			IResource dfile = ResourcesPlugin.getWorkspace().getRoot();
			try {
				dfile.refreshLocal(IResource.DEPTH_INFINITE, null);
			} catch (CoreException e) {
				e.printStackTrace();
			}
		} catch (InvocationTargetException e) {
			return false;
		} catch (InterruptedException e) {
			return false;
		} 
		return true;
	}

	/***
	 * This method will be used to create a file and folder for the Test
	 * 
	 * @param file
	 * @throws CoreException
	 */
	private void createFile(IFile file) throws CoreException {

		new File(folder.getParent().getLocation().toString() + "\\Configuration").mkdir();
		File f = new File(folder.getParent().getLocation().toString() + "\\Configuration\\"+file.getName());

		PrintWriter out = null;
		try {
			out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
			out.println("# Enter Your Configuration related data");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}
		IResource dfile = ResourcesPlugin.getWorkspace().getRoot();

		dfile.refreshLocal(IResource.DEPTH_INFINITE, null);
	}
	
	private void setTestNGClassPath(){
		List<String> fileContent = null;
		java.nio.file.Path FILE_PATH = Paths.get(folder.getParent().getLocation().toString() + "/.classpath");
        try {
            fileContent = new ArrayList<String>(Files.readAllLines(FILE_PATH, StandardCharsets.UTF_8));
            for (int i = 0; i < fileContent.size(); i++) {
            	if (fileContent.get(i).trim().equalsIgnoreCase("<classpathentry kind=\"output\" path=\"bin\"/>")) {
                    fileContent.set(i, fileContent.get(i).replace("<classpathentry kind=\"output\" path=\"bin\"/>", "<classpathentry kind=\"con\" path=\"org.testng.TESTNG_CONTAINER\"/>\n\t<classpathentry kind=\"output\" path=\"bin\"/>"));
                    break;
                }
            }
            Files.write(FILE_PATH, fileContent, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
	}
}