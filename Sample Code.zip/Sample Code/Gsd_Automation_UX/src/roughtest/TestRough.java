/*package roughtest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class TestRough {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String a="abc";
		HashMap<String,String> serviceAttributesList=new HashMap<String,String>();
		serviceAttributesList.put("A",a);
		Set keys = serviceAttributesList.keySet();
		Iterator itr=keys.iterator();
	    while (itr.hasNext()) {
	        String key = (String)itr.next();
	        String value=serviceAttributesList.get(key);
	        if(value.equals("")){
		    	System.out.println(key+" is emty and no system returned values");
		    }
		    else{
		    	
		    	System.out.println("For "+key+"--> displayed attribute is : "+value);
		    }
	        
	        
	      }
	   

	}

}
*/