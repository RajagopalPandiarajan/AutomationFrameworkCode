package com.hashworks.delta_uat_automation.workflows;

import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hashworks.delta_uat_automation.pages.HomePage;
import com.hashworks.delta_uat_automation.pages.ResponsibilityPage;
import com.hashworks.delta_uat_automation.utility.CommonUtility;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class ResponsibilityWorkFlow {

	public ResponsibilityWorkFlow () {
	}
	
	public boolean validate() {
		return false;
	}
	public void AddResponsibilitiesUX(WebDriver driver, String UserID, String Name, String Responsibility1, String Responsibility2, String Responsibility3 ) throws Exception
	{
		ResponsibilityPage ResponsibilityPageobj = new ResponsibilityPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.acknowledgeButton()));
		driver.findElement(HomePageobj.acknowledgeButton()).click();
		//ClosePopUp(driver);
		
		System.out.println("Entered into the ResponsibilitySettings Method...........");
		try
		{
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkSiteMap()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkSiteMap()));
			driver.findElement(ResponsibilityPageobj.lnkSiteMap()).click();
			System.out.println("Clicked on the Site Map");
		
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.searchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.searchTextBox()));
			driver.findElement(ResponsibilityPageobj.searchTextBox()).sendKeys("Administration - User");
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkAdministratorUser()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkAdministratorUser()));
			driver.findElement(ResponsibilityPageobj.lnkAdministratorUser()).click();
			System.out.println("Clicked on the Administrator User Link");
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserID()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserID()));
			driver.findElement(ResponsibilityPageobj.txtUserID()).sendKeys(UserID);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserName()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserName()));
			driver.findElement(ResponsibilityPageobj.txtUserName()).sendKeys(Name);
		
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnUserIDButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnUserIDButton()));
			driver.findElement(ResponsibilityPageobj.btnUserIDButton()).click();
			System.out.println("User ID Search Completed");
		
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).click();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton3()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton3()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton3()).click();
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility1);
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility2);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility3);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			driver.findElement(ResponsibilityPageobj.btnRespAddRmvOkButton()).click();
			System.out.println("Added all the Responsibilities in the screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).sendKeys(Keys.TAB);
			System.out.println("Saved all the responsibilities");
			AddFSDSecurities(driver, "User ID", "Rajagopal_P", "test_Japan", "TEST Automation AMER","TEST Automation EMEA","TEST Automation AP","FEDERAL");

			try
			{
				Logout(driver);
				System.out.println("Delta is logged out");
			}
			catch(Exception e)
			{
				System.out.println("Caught while logging out Delta");
			}
			try
			{
				//OpenDelta(driver);
				//ClosePopUp(driver);
			}
			catch(Exception e)
			{
				System.out.println("Caught while openning Delta");
			}
		
		}
		catch(Exception e)
		{
			System.out.println("Caught while adding the responsibilities");
		}
		
	}
	
	//// Responsibility Function for FSD
	
	public void AddResponsibilitiesFSD(WebDriver driver, String UserID, String Name, String Responsibility1, String Responsibility2, String Responsibility3, String Responsibility4 ) throws Exception
	{
		ResponsibilityPage ResponsibilityPageobj = new ResponsibilityPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.acknowledgeButton()));
		driver.findElement(HomePageobj.acknowledgeButton()).click();
		//ClosePopUp(driver);
		
		System.out.println("Entered into the ResponsibilitySettings Method...........");
		try
		{
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkSiteMap()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkSiteMap()));
			driver.findElement(ResponsibilityPageobj.lnkSiteMap()).click();
			System.out.println("Clicked on the Site Map");
		
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.searchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.searchTextBox()));
			driver.findElement(ResponsibilityPageobj.searchTextBox()).sendKeys("Administration - User");
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkAdministratorUser()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkAdministratorUser()));
			driver.findElement(ResponsibilityPageobj.lnkAdministratorUser()).click();
			System.out.println("Clicked on the Administrator User Link");
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserID()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserID()));
			driver.findElement(ResponsibilityPageobj.txtUserID()).sendKeys(UserID);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserName()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserName()));
			driver.findElement(ResponsibilityPageobj.txtUserName()).sendKeys(Name);
		
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnUserIDButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnUserIDButton()));
			driver.findElement(ResponsibilityPageobj.btnUserIDButton()).click();
			System.out.println("User ID Search Completed");
		
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).click();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton3()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton3()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton3()).click();
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility1);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility2);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility3);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility4);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			driver.findElement(ResponsibilityPageobj.btnRespAddRmvOkButton()).click();
			System.out.println("Added all the Responsibilities in the screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).sendKeys(Keys.TAB);
			System.out.println("Saved all the responsibilities");
			AddFSDSecurities(driver, "User ID", "Rajagopal_P", "test_Japan", "TEST Automation AMER","TEST Automation EMEA","TEST Automation AP","FEDERAL");

			try
			{
				Logout(driver);
				System.out.println("Delta is logged out");
			}
			catch(Exception e)
			{
				System.out.println("Caught while logging out Delta");
			}
			try
			{
				OpenDelta(driver);
				//ClosePopUp(driver);
			}
			catch(Exception e)
			{
				System.out.println("Caught while openning Delta");
			}
		
		}
		catch(Exception e)
		{
			System.out.println("Caught while adding the responsibilities");
		}
		
	}

	
	
	
	public void AddResponsibilitiesCRE(WebDriver driver, String UserID, String Name, String Responsibility1, String Responsibility2) throws Exception
	{
		ResponsibilityPage ResponsibilityPageobj = new ResponsibilityPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.acknowledgeButton()));
		driver.findElement(HomePageobj.acknowledgeButton()).click();
		//ClosePopUp(driver);
		
		System.out.println("Entered into the ResponsibilitySettings Method...........");
		try
		{
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkSiteMap()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkSiteMap()));
			driver.findElement(ResponsibilityPageobj.lnkSiteMap()).click();
			System.out.println("Clicked on the Site Map");
		
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.searchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.searchTextBox()));
			driver.findElement(ResponsibilityPageobj.searchTextBox()).sendKeys("Administration - User");
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.lnkAdministratorUser()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.lnkAdministratorUser()));
			driver.findElement(ResponsibilityPageobj.lnkAdministratorUser()).click();
			System.out.println("Clicked on the Administrator User Link");
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserID()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserID()));
			driver.findElement(ResponsibilityPageobj.txtUserID()).sendKeys(UserID);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtUserName()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtUserName()));
			driver.findElement(ResponsibilityPageobj.txtUserName()).sendKeys(Name);
		
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnUserIDButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnUserIDButton()));
			driver.findElement(ResponsibilityPageobj.btnUserIDButton()).click();
			System.out.println("User ID Search Completed");
		
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).click();
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton3()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton3()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton3()).click();
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility1);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).clear();
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Responsibility2);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.txtRespSearchBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.txtRespSearchBox()));
			driver.findElement(ResponsibilityPageobj.txtRespSearchBox()).sendKeys(Keys.ENTER);
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespRmvButton1()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespRmvButton1()));
			driver.findElement(ResponsibilityPageobj.btnRespRmvButton1()).click();
			
					
			
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnRespAddRmvOkButton()));
			driver.findElement(ResponsibilityPageobj.btnRespAddRmvOkButton()).click();
			System.out.println("Added all the Responsibilities in the screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnRespButton()));
			driver.findElement(ResponsibilityPageobj.btnRespButton()).sendKeys(Keys.TAB);
			System.out.println("Saved all the responsibilities");
			RemoveAllFSDSecurities(driver, "User ID", "Rajagopal_P");

			try
			{
				Logout(driver);
				System.out.println("Delta is logged out");
			}
			catch(Exception e)
			{
				System.out.println("Caught while logging out Delta");
			}
			try
			{
				//OpenDelta(driver);
				//ClosePopUp(driver);
			}
			catch(Exception e)
			{
				System.out.println("Caught while openning Delta");
			}
		
		}
		catch(Exception e)
		{
			System.out.println("Caught while adding the responsibilities");
		}
		
	}
	
	
	public void AddFSDSecurities(WebDriver driver, String UserID, String Name, String FSDSecurity1, String FSDSecurity2, String FSDSecurity3, String FSDSecurity4, String FSDSecurity5) throws Exception
	{
		ResponsibilityPage ResponsibilityPageobj = new ResponsibilityPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
			
		
		System.out.println("Entered into the FSD Security Settings Method...........");
		try
		{
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDbutton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDbutton()));
			driver.findElement(ResponsibilityPageobj.btnFSDbutton()).click();
			
			
		
	
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			Thread.sleep(3000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDRmvButton3()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDRmvButton3()));
			driver.findElement(ResponsibilityPageobj.btnFSDRmvButton3()).click();
			
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(FSDSecurity1);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(Keys.ENTER);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).clear();
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(FSDSecurity2);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(Keys.ENTER);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).clear();
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(FSDSecurity3);
		
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(Keys.ENTER);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).clear();
			
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(FSDSecurity4);
			//driver.findElement(By.name("s_6_1_133_0")).sendKeys("TEST Automation AMER");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(Keys.ENTER);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).clear();
			
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(FSDSecurity5);
			//driver.findElement(By.name("s_6_1_133_0")).sendKeys("TEST Automation AMER");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.FSDSearchTextBox()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.FSDSearchTextBox()));
			driver.findElement(ResponsibilityPageobj.FSDSearchTextBox()).sendKeys(Keys.ENTER);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			

			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDAddRmvOkButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDAddRmvOkButton()));
			driver.findElement(ResponsibilityPageobj.btnFSDAddRmvOkButton()).click();
	
			
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDbutton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDbutton()));
			driver.findElement(ResponsibilityPageobj.btnFSDbutton()).sendKeys(Keys.TAB);
			//driver.close();
		}
		
		
		catch(Exception e)
		{
			System.out.println("Caught while adding the FSD Securities");
		}
		
	}
	
	///// Removing all the FSDs
	
	public void RemoveAllFSDSecurities(WebDriver driver, String UserID, String Name) throws Exception
	{
		ResponsibilityPage ResponsibilityPageobj = new ResponsibilityPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
			
		
		System.out.println("Entered into the FSD Security Remove all Method...........");
		try
		{
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDbutton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDbutton()));
			driver.findElement(ResponsibilityPageobj.btnFSDbutton()).click();
			
		
			System.out.println(ResponsibilityPageobj.btnFSDaddbutton1());
			System.out.println("Printed the FSDAddButton1");
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDaddbutton1()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDaddbutton1()));
			driver.findElement(ResponsibilityPageobj.btnFSDaddbutton1()).click();
			
			Thread.sleep(3000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDRmvButton3()));
			//wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDRmvButton3()));
			driver.findElement(ResponsibilityPageobj.btnFSDRmvButton3()).click();
			
			
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDAddRmvOkButton()));
			//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='FSD Security:OK']")));
			driver.findElement(ResponsibilityPageobj.btnRespAddRmvOkButton()).click();
			//button[@title='FSD Security:OK']
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(ResponsibilityPageobj.btnFSDbutton()));
			wait.until(ExpectedConditions.elementToBeClickable(ResponsibilityPageobj.btnFSDbutton()));
			driver.findElement(ResponsibilityPageobj.btnFSDbutton()).sendKeys(Keys.TAB);
			//driver.close();
		}
		
		
		catch(Exception e)
		{
			System.out.println("Caught while adding the FSD Securities");
		}
		
	}
	


	
		public void Logout(WebDriver driver) throws Exception
	{
		HomePage HomePageobj = new HomePage();
		HomePageobj.LogOutButton(driver).click();
	}
	
	public void OpenDelta (WebDriver driver) throws IOException
	{
		driver = new InternetExplorerDriver();

		Properties obj_property;
		obj_property=CommonUtility.loadPropertyFile();
		driver.get(obj_property.getProperty("url"));
	
	}
	
	public void ClosePopUp(WebDriver driver) throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver, 240);
		HomePage HomePageobj = new HomePage();
		
        try{
        	int expectedNumberOfWindows=2;
        	wait.until(ExpectedConditions.numberOfWindowsToBe(expectedNumberOfWindows));
            Iterator<String> itr=driver.getWindowHandles().iterator();

              String mainWin=driver.getWindowHandle();
              while(itr.hasNext())
              {
                     
                     driver.switchTo().window(itr.next());
              }
              Thread.sleep(2000);//4000
              //wait.until(ExpectedCondition)
              wait.until(ExpectedConditions.elementToBeClickable(HomePageobj.popupCloseButton(driver)));
              HomePageobj.popupCloseButton(driver).click();
              driver.switchTo().window(mainWin);
              Thread.sleep(2000);
        }
        catch(Exception e){
              System.out.println("caught exception while handling pop up"+e);
        }


	}
	
	
}
