package com.hashworks.delta_uat_automation.workflows;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hashworks.delta_uat_automation.pages.AssetsPage;
import com.hashworks.delta_uat_automation.pages.ReviewAddressAndDetailsPage;

public class CreateDispatchNegWorkFlow {

	public CreateDispatchNegWorkFlow () {
	}
	
	public boolean validate() {
		return false;
	}
	@SuppressWarnings("null")
	public void CreateDispatchNeg (WebDriver driver)
	{
		ReviewAddressAndDetailsPage ReviewAddressAndDetailsPageobj = new ReviewAddressAndDetailsPage();
		AssetsPage AssetsPageobj = new AssetsPage();
		WebDriverWait wait = new WebDriverWait(driver, 240);

		System.out.println("Entered into the Create Dispatch Nagative Scenario Method");
		try
		{
			System.out.println("Clicking on the Create Dispatch Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(ReviewAddressAndDetailsPageobj.getCreateDispatchButton()));
			wait.until(ExpectedConditions.elementToBeClickable(ReviewAddressAndDetailsPageobj.getCreateDispatchButton()));
			driver.findElement(ReviewAddressAndDetailsPageobj.getCreateDispatchButton()).click();
			Thread.sleep(20000);
			//wait.until(ExpectedConditions.alertIsPresent());
			Alert al = driver.switchTo().alert();
			String message = al.getText();
			System.out.println("Test of the alrt"+message);
			al.accept();
			//driver.close();
			}
		
		catch(Exception e)
		{
			e.printStackTrace();
			//System.exit(1);
		}
		
	}
		



public void CreateDispatch2 (WebDriver driver)
{
	ReviewAddressAndDetailsPage obj_ReviewAddressAndDetailsPage=new ReviewAddressAndDetailsPage(); 
	WebDriverWait wait= new WebDriverWait(driver,120);
	
	System.out.println("Entered into the Create Dispatch Nagative Scenario Method for 2nd CRE TC");
	try
	{
		System.out.println("Clicking on the Create Dispatch Button....");
		/*wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
	    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
		System.out.println("Initiated creating dispatch");
	    driver.findElement(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()).click();
	    System.out.println("Clicked on the Create Dispatch Button");*/
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.name("s_2_1_28_0")));
		wait.until(ExpectedConditions.elementToBeClickable(By.name("s_2_1_28_0")));
		driver.findElement(By.name("s_2_1_28_0")).click();
		
		//Thread.sleep(10000);
		//driver.findElement(By.name("s_2_1_22_0")).click();
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//button[@title='ISP Dispatch Address Asset:COPY >']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='ISP Dispatch Address Asset:COPY >']")));
		driver.findElement(By.xpath("//button[@title='ISP Dispatch Address Asset:COPY >']")).click();
		
		//wait.until(ExpectedConditions.elementToBeClickable(By.name("s_11_1_39_0")));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//button[@title='Address Validation:OK']")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Address Validation:OK']")));
		driver.findElement(By.xpath("//button[@title='Address Validation:OK']")).click();
		
		Thread.sleep(5000);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(obj_ReviewAddressAndDetailsPage.AddAddress()));
		wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.AddAddress()));
		driver.findElement(obj_ReviewAddressAndDetailsPage.AddAddress()).click();
		
		//Thread.sleep(5000);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		driver.findElement(obj_ReviewAddressAndDetailsPage.ProcessTypeText()).clear();
		
		//Thread.sleep(5000);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		driver.findElement(obj_ReviewAddressAndDetailsPage.ProcessTypeText()).sendKeys("Order Never Invoiced - Japan EXG");
		
		//Thread.sleep(5000);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.ProcessTypeText()));
		driver.findElement(obj_ReviewAddressAndDetailsPage.ProcessTypeText()).sendKeys(Keys.ENTER);
		
		//Thread.sleep(5000);
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(obj_ReviewAddressAndDetailsPage.NextButtonName()));
		wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.NextButtonName()));
		driver.findElement(obj_ReviewAddressAndDetailsPage.NextButtonName()).click();
		
		Thread.sleep(5000);
		Alert al = driver.switchTo().alert();
		String message = al.getText();
		System.out.println("Test of the alrt"+message);
		al.accept();
		//driver.close();
		
		}
	
	catch(Exception e)
	{
		e.printStackTrace();
		//System.exit(1);
	}
	
}



}
