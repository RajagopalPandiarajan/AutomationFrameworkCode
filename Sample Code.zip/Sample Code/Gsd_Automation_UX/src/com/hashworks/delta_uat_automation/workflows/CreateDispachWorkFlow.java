package com.hashworks.delta_uat_automation.workflows;

import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hashworks.delta_uat_automation.pages.ReviewAddressAndDetailsPage;
import com.hashworks.delta_uat_automation.pages.ReviewAddressAndDetailsPageUX;
import com.hashworks.delta_uat_automation.pages.ReviewAndSelectPartsPage;
import com.hashworks.delta_uat_automation.pages.ReviewAndSubmitDispatchPage;
import com.hashworks.delta_uat_automation.pages.ReviewAndSubmitDispatchPageUX;

public class CreateDispachWorkFlow {

	ReviewAddressAndDetailsPage obj_ReviewAddressAndDetailsPage=new ReviewAddressAndDetailsPage(); 
	
	ReviewAddressAndDetailsPageUX obj_ReviewAddressAndDetailsPageUX=new ReviewAddressAndDetailsPageUX(); 

	//WebDriverWait wait=null;
	ReviewAndSubmitDispatchPage obj_ReviewAndSubmitDispatchPage=new ReviewAndSubmitDispatchPage();
	
	ReviewAndSubmitDispatchPageUX obj_ReviewAndSubmitDispatchPageUX=new ReviewAndSubmitDispatchPageUX();

	
	ReviewAndSelectPartsPage obj_ReviewAndSelectPartsPage=new ReviewAndSelectPartsPage();
	
	String OOwText;
	
	
	
	
	
	
	public void DispatchCreation_BreakFix(WebDriver driver, String serviceType, String partNumber)
	{
		try
		{
			Thread.sleep(5000);
			WebDriverWait wait=new WebDriverWait(driver,150);
			System.out.println("Entered into DispatchCreation_BreakFix method..........");
			//Selecting Repeat Reason
			
			
				String repeatDispatch=driver.findElement(obj_ReviewAndSubmitDispatchPage.getrepeatDispatch()).getAttribute("value");
			    System.out.println("repeatDispatch" +repeatDispatch);
			    int countRepeatOfrepeatDispatch=Integer.parseInt(repeatDispatch);
			    System.out.println("Repeat count"+countRepeatOfrepeatDispatch);
			    if(countRepeatOfrepeatDispatch>0){
				System.out.println("Entering Repeat Reason");
				driver.findElement(obj_ReviewAddressAndDetailsPage.txtRepeatReason()).sendKeys("Customer Availability");
				driver.findElement(obj_ReviewAddressAndDetailsPage.txtRepeatReason()).sendKeys(Keys.TAB);
		
			    }
			System.out.println("Clicking on the Create Dispatch Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
			System.out.println("Initiated creating dispatch");
		    driver.findElement(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()).click();
		    
		    ManullyAddressAndValidation(driver);
		    
		    SelectServiceType_ServiceOption(driver, serviceType);
		    
		    if(serviceType.contains("Parts Only"))
		    {
		    	AddParts_LineItem(driver,partNumber);
		    }
		    
		    if(serviceType.contains("Parts and Labor"))
		    {
		    	AddParts_Manually(driver);
		    }
		    
		   // createInstruction(driver);
		    
		  
		  //  System.out.println("I am here now");
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.nextButtonUnderSubmit()));
		    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPage.nextButtonUnderSubmit()));
		  //  System.out.println("I waited and I am here now");
		    driver.findElement(obj_ReviewAndSubmitDispatchPage.nextButtonUnderSubmit()).click();
		    //System.out.println("It Clicked");		    
		    
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.submitButton()));

		    driver.findElement(obj_ReviewAndSubmitDispatchPage.submitButton()).click();
		    //Fetching the dps number.....
		   /* String dpsNumber=obj_ReviewAndSubmitDispatchPage.fetchDispatchNumber(driver).getAttribute("value").trim();
		    String dpsStatus=obj_ReviewAndSubmitDispatchPage.fetchDispatchStatus(driver).getAttribute("value").trim();
		    String dpsSubStatus=obj_ReviewAndSubmitDispatchPage.fetchDispatchSubStatus(driver).getAttribute("value").trim();
		    String dpsRegion=obj_ReviewAndSubmitDispatchPage.fetchDispatchRegion(driver).getAttribute("value").trim();
		    String dpsBUID=obj_ReviewAndSubmitDispatchPage.fetchDispatchBUID(driver).getAttribute("value").trim();
		    System.out.println("dpsNumber:"+dpsNumber);*/
		    
		    /*String dpsNumber=driver.findElement(obj_ReviewAndSubmitDispatchPage.dpsNoUnderActivity()).getAttribute("value");
		    String dpsRegion=driver.findElement(obj_ReviewAndSubmitDispatchPage.regionUnderActivity()).getAttribute("value");
		    */
		    
		    String dpsNumber=driver.findElement(obj_ReviewAndSubmitDispatchPage.dpsNoUnderActivity()).getAttribute("value");

		    //String dpsRegion=driver.findElement(obj_ReviewAndSubmitDispatchPage.regionUnderActivity()).getAttribute("value");
		    
		    
		    if(dpsNumber==null || dpsNumber=="" || dpsNumber.isEmpty())
		    {
		    	System.out.println("The Dispatch Number is: "+dpsNumber);
		    	System.out.println("Dispatch Creation Failed......");
		    	System.exit(1);
		    }
		    
		    System.out.println("Dispatch Created Successfully, The Dispatch Number is: "+dpsNumber);
		    //System.out.println("Dispatch Created Successfully, The Dispatch Status is: "+dpsRegion);
		    /*System.out.println("Dispatch Created Successfully, The Dispatch SubStatus is: "+dpsSubStatus);
		    System.out.println("Dispatch Created Successfully, The Dispatch Region is: "+dpsRegion);
		    System.out.println("Dispatch Created Successfully, The Dispatch BUID is: "+dpsBUID);
		    System.out.println("Dispatch Created Successfully, The Service Type is: "+serviceType);
			*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
		
	}
	
	
	public void ManullyAddressAndValidation(WebDriver driver) throws Exception{
		    
		try{
			
		    driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		    WebDriverWait wait=new WebDriverWait(driver,150);
			
   		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()));
   		    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()));
			//driver.findElement(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()).sendKeys(testDataForTc_1358564.get("AddressLine1"));
			/*System.out.println("clearing address line 1  ");
			driver.findElement(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()).clear();;*/
			System.out.println("Entering address line 1  ");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()).sendKeys("1 dell way");
			
		    driver.findElement(obj_ReviewAddressAndDetailsPage.getCityTextBox()).clear();
		    System.out.println("Entering text into city text box ");
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCityTextBox()));
		    driver.findElement(obj_ReviewAddressAndDetailsPage.getCityTextBox()).sendKeys("Paris");
			
			//driver.findElement(obj_ReviewAddressAndDetailsPage.getCountryTextBox()).sendKeys(testDataForTc_1358564.get("country"));
		    //driver.findElement(obj_ReviewAddressAndDetailsPage.getCountryTextBox()).clear();
			
		    System.out.println("Entering text into country text box ");
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCountryTextBox()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getCountryTextBox()).sendKeys("France");
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCountryTextBox()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getCountryTextBox()).sendKeys(Keys.ENTER);
			
			System.out.println("Entering text into state/counrty arrow");
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getStateOrCountyDropDownArrow()));
			//driver.findElement(obj_ReviewAddressAndDetailsPage.getStateOrCountyDropDownArrow()).click();
			
			
			
			driver.findElement(obj_ReviewAddressAndDetailsPage.stateOrCountyDropDownTextBox()).click();
			System.out.println("select item from dropdow item");
			driver.findElement(obj_ReviewAddressAndDetailsPage.stateOrCountyDropDownTextBox()).sendKeys("UN");
			driver.findElement(obj_ReviewAddressAndDetailsPage.stateOrCountyDropDownTextBox()).sendKeys(Keys.TAB);
			//driver.findElement(obj_ReviewAddressAndDetailsPage.getDropDownItem()).click();
			
			
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getPostalCodeTextBox()));
			System.out.println("clicking on text into postal textbox");
			driver.findElement(obj_ReviewAddressAndDetailsPage.getPostalCodeTextBox()).click();
			
			driver.findElement(obj_ReviewAddressAndDetailsPage.getPostalCodeTextBox()).clear();
			driver.findElement(obj_ReviewAddressAndDetailsPage.getPostalCodeTextBox()).clear();
			System.out.println("Entering text into postal textbox");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getPostalCodeTextBox()).sendKeys("75008");//77002
			
			System.out.println("clicking on do not update check box");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox()).click();
			
			System.out.println("clicking on validate button");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getValidateButton()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getValidateButton()).click();
	        Thread.sleep(3000);
		
	        try{
				
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("Alert Message displayed after clicking on Validate button:"+alert.getText());
				alert.accept();
				System.err.println("Error message");
				//System.exit(1);
			}
			catch(NoAlertPresentException e){
				System.out.println("parts is avialable for the service tag");
			}
	        
			/*System.out.println("clicking on ok button of address validation pop-up");
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getOkButtonOfAddessValidation()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getOkButtonOfAddessValidation()).click();
			*/
	        
			System.out.println("clicking on Next button of ReviewAddressAndDetails screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getNextButton()));
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getNextButton()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getNextButton()).click();
			
			wait.until(ExpectedConditions.alertIsPresent());
			try{
				
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				
				OOwText=alert.getText();
				System.out.println("Alert Message displayed after clicking on Validate button:"+alert.getText());
				alert.accept();
				//System.err.println("Error message");
				//System.exit(1);
			}
			catch(NoAlertPresentException e){
				System.out.println("parts is avialable for the service tag");
			}
			
	        
			
			
			
			
		}
		catch(Exception e){
			System.out.println("Exception caught while executing the method in validationOnUpdateDispatchAddress "+e);
			e.printStackTrace();
		}
			
	}
	
	public void SelectServiceType_ServiceOption(WebDriver driver, String serviceType)
	{
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	    WebDriverWait wait=new WebDriverWait(driver,150);
	    
		System.out.println("Entered into SelectServiceType_ServiceOption...... ");
		try
		{
			System.out.println("clicking on service type");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()));
			
			if(driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).isDisplayed()){
				System.out.println("service type is displayed");
			}
			else{
				System.out.println("service type is not displayed");
			}
			
			driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).click();
			driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).clear();
			//wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.getServiceTextBox()));
			//obj_ReviewAndSubmitDispatchPage.getServiceTextBox(driver).click();
			
			
			System.out.println("Entering text into service type");
			//obj_ReviewAndSubmitDispatchPage.getServiceTextBox(driver).clear();
			driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).sendKeys(serviceType);
			//obj_ReviewAndSubmitDispatchPage.getServiceTextBox(driver).sendKeys(serviceType);
			//obj_ReviewAndSubmitDispatchPage.getServiceTextBox(driver).sendKeys(Keys.TAB);
			//driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).sendKeys(Keys.TAB);
			driver.findElement(obj_ReviewAndSubmitDispatchPage.serviceTypeTextBox()).sendKeys(Keys.TAB);
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.getServiceOptionsList()));
			driver.findElement(obj_ReviewAndSubmitDispatchPage.getServiceOptionsList()).clear();
			driver.findElement(obj_ReviewAndSubmitDispatchPage.getServiceOptionsList()).sendKeys("Next Business Day-8x5");
			driver.findElement(obj_ReviewAndSubmitDispatchPage.getServiceOptionsList()).sendKeys(Keys.TAB);
			try{
			if(OOwText.equalsIgnoreCase("System Out Of Warranty and is Billable")){
			System.out.println("Entering Bill to filed deatils");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.getBillToTextBox()));
			driver.findElement(obj_ReviewAndSubmitDispatchPage.getBillToTextBox()).sendKeys("Customer");
			
			System.out.println("Entering Reference deatils");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.getReferenceTextBox()));
			driver.findElement(obj_ReviewAndSubmitDispatchPage.getReferenceTextBox()).sendKeys("1");
			}}
			catch(Exception e){
				System.out.println("System is not Out Of Warranty");
			}
			
			}
		
		catch(Exception e)
		{
			e.printStackTrace();
			//System.exit(1);
		}
	}
	
	public void AddParts_LineItem(WebDriver driver, String partNumber ) {
		// TODO Auto-generated method stub
		WebDriverWait wait=new WebDriverWait(driver,150);
		try
		{		
		System.out.println("click on Add Parts");
		//obj_ReviewAndSubmitDispatchPage.getAddParts(driver).click();
		//driver.findElement(obj_ReviewAndSubmitDispatchPage.addParts()).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.addParts()));
		driver.findElement(obj_ReviewAndSubmitDispatchPage.addParts()).click();
		Thread.sleep(10000);
		try{
			
			Alert alertgetParts=driver.switchTo().alert();
			System.out.println("Switched to alert pop-up");
			System.out.println("alert Message didplayed after clicking add parts:"+alertgetParts.getText());
			alertgetParts.accept();
			
		}
		catch(NoAlertPresentException e){
			//System.out.println("parts is avialable for the service tag");
		}
		
		//wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getPartsToBeDispatchedNewButton()));
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@aria-label='Parts To Be Dispatched:New']")));
		wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getPartsToBeDispatchedNewButton()));
		System.out.println("click on new button of Parts to be disptached");
		//driver.findElement(obj_ReviewAndSelectPartsPage.getPartsToBeDispatchedNewButton()).click();
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsToBeDispatchedNewButton()).click();
		
		/*System.out.println("Entering part no");
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).clear();
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).sendKeys(partNumber);
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).sendKeys(Keys.TAB);
		*/
		
		
		System.out.println("Entering part no");
		//driver.findElement(By.name("ISP_Part_No")).sendKeys(partNumber);;
		wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getPartsNo()));
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).clear();
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).sendKeys(partNumber);
		driver.findElement(obj_ReviewAndSelectPartsPage.getPartsNo()).sendKeys(Keys.TAB);
		
		
		
		
		
		
		System.out.println("Part 00001 has been added successfully.....");
		
		System.out.println("clicking on  Review button");		
		//obj_ReviewAndSelectPartsPage.getReviewButton(driver).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getReviewButton()));
		driver.findElement(obj_ReviewAndSelectPartsPage.getReviewButton()).click();
	//	System.out.println("It clicked on the review button");
		
		
		}
		catch(Exception e){
			
			System.out.println("Caught exception while excuting dispatchTypeWithPatrsonly method: "+e);
			e.printStackTrace();
		}
	}

	
	public void AddParts_Manually(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);
		try
		{
			System.out.println("Entered into AddParts_Manually method.........");
			
			System.out.println("click on Add Parts");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.addParts()));
			driver.findElement(obj_ReviewAndSubmitDispatchPage.addParts()).click();
			//obj_ReviewAndSubmitDispatchPage.getAddParts(driver).click();
			Thread.sleep(10000);

			
			try{
				//wait.until(ExpectedConditions.alertIsPresent());
				Alert alertgetParts=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("alert Message didplayed after clicking add parts:"+alertgetParts.getText());
				alertgetParts.accept();
			}
			catch(NoAlertPresentException e){
				System.out.println("parts is avialable for the service tag");
			}

			//Clicking on the Manual Button
			System.out.println("Clicking on the Manual Button....");
			//obj_ReviewAndSelectPartsPage.btnManual(driver).click();
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getManualButton()));
			driver.findElement(obj_ReviewAndSelectPartsPage.getManualButton()).click();
			
			Thread.sleep(3000);
			
			try{
				//wait.until(ExpectedConditions.alertIsPresent())
				Alert alertManualButton=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("alert Message didplayed after clicking Manual Button:"+alertManualButton.getText());
				alertManualButton.accept();
				
				
			}
			catch(NoAlertPresentException e){
				//System.out.println("Manual button alert");
			}
			
			System.out.println("Clicking on the Select Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getSelectButton()));
			driver.findElement(obj_ReviewAndSelectPartsPage.getSelectButton()).click();
			//obj_ReviewAndSelectPartsPage.btnSelect(driver).click();
			
			System.out.println("Clicking on the Add Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getAddButtonUnderPartSelection()));
			driver.findElement(obj_ReviewAndSelectPartsPage.getAddButtonUnderPartSelection()).click();
			//obj_ReviewAndSelectPartsPage.btnAdd(driver).click();
			Thread.sleep(2000);//can reduce
			
            try{
				
            	//wait.until(ExpectedConditions.alertIsPresent());
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("Alert Message displayed agetr clicking on Add Button :"+alert.getText());
				alert.accept();
				
				
			}
			catch(NoAlertPresentException e){
				//System.out.println("Manual button alert");
			}
			
			///Thread.sleep(8000);
			
			System.out.println("Clicking on the Review Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSelectPartsPage.getReviewButton()));
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSelectPartsPage.getReviewButton()));
			driver.findElement(obj_ReviewAndSelectPartsPage.getReviewButton()).click(); /// DO WE NEED TO CLICK ON THE REVIEW BUTTON?
			//obj_ReviewAndSelectPartsPage.getReviewButton(driver).click();
			///Thread.sleep(10000);
			
			System.out.println("Parts has been added successfully.......");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//System.exit(1);
		}
	}

	
		
		public void createInstruction(WebDriver driver,String receiver,String type,String instructionData) {
			
			// TODO Auto-generated method stub
		
		  driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		  WebDriverWait wait=new WebDriverWait(driver,150);
			try{
				Thread.sleep(5000);		
				System.out.println("Clicking on new button of Instruction");
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionNewButton()).click();
				Thread.sleep(3000);
				System.out.println("Entering receiver data");
				wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.instructionRecieverField()));
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionRecieverField()).sendKeys(receiver);
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionRecieverField()).sendKeys(Keys.TAB);
				
				//Thread.sleep(4000);
				
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionType()).sendKeys(type);
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionType()).sendKeys(Keys.TAB);
				Thread.sleep(1000);
				
				System.out.println("Entering data into instruction");
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionField()).sendKeys(instructionData);
				//driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionField()).sendKeys(Keys.ENTER);
				//System.out.println("1");
				driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionField()).sendKeys(Keys.TAB);
			//	System.out.println("2");
				Thread.sleep(1000);
				//driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionCreatedByField()).sendKeys(Keys.TAB);
				//driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionCreatedByField()).sendKeys(Keys.ENTER);
				Thread.sleep(2000);
				//handleAlert(driver);
				//Thread.sleep(4000);	
				 try{
						System.out.println("switched to alert");
						Alert alertDuplicate=driver.switchTo().alert();
						
						System.out.println("Alert Message displayed:"+alertDuplicate.getText());
						
						alertDuplicate.accept();
						
						
					}
					catch(NoAlertPresentException e){
						//System.out.println("parts is avialable for the service tag");
					}
				
				
				
				
			}
		
			catch(Exception e){
			
				System.out.println("Caught exception while excuting createInstruction method: "+e);
				e.printStackTrace();			
				}
			
	}
			
	


	public void validateServiceAttributes(WebDriver driver) throws Exception{
		    driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		    WebDriverWait wait=new WebDriverWait(driver,150);
		    HashMap<String,String> serviceAttributesList=new HashMap<String,String>();
		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPage.getCurrentEntitlementTextBox()));
		    String currentEntitlement=driver.findElement(obj_ReviewAndSubmitDispatchPage.getCurrentEntitlementTextBox()).getAttribute("value");
		    //System.out.println("CurrentEntitlement:"+currentEntitlement_Element.getText());
		     
		    String locationCoverage=driver.findElement(obj_ReviewAndSubmitDispatchPage.getLocationCoverageTextBox()).getAttribute("value");
		    serviceAttributesList.put("locationCoverage",locationCoverage);
		    String premierType=driver.findElement(obj_ReviewAndSubmitDispatchPage.getPremierTypeTextBox()).getAttribute("value");
		    serviceAttributesList.put("premierType",premierType);
		
		    Iterator<String> iterator_service = serviceAttributesList.keySet().iterator();

		    while (iterator_service.hasNext()) {
		        String key =iterator_service.next();
		        String value=serviceAttributesList.get(key);
		        if(value.equals("")){
			    	System.out.println(key+" is emty and no system returned values");
			    }
			    else{
			    	
			    	System.out.println("For "+key+"--> displayed attribute is : "+value);
			    }
		        
		        
		      }
		   
		  
		    
		    
		    
		    
		    	    
		
	}
	
	

	public void validateServiceScheduleFields(WebDriver driver) throws Exception{
		
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	    HashMap<String,String> serviceScheduleFields=new HashMap<String,String>();
		String serviceOptionsValue=driver.findElement(obj_ReviewAndSubmitDispatchPage.getServiceOptionsList()).getAttribute("value");
		String arrivalWindowStartValue=driver.findElement(obj_ReviewAndSubmitDispatchPage.getArrivalWindowStartTextBox()).getAttribute("value");		
		String timezoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPage.getTimezoneTextBox()).getAttribute("value");				
		String arrivalWindowEndValue=driver.findElement(obj_ReviewAndSubmitDispatchPage.getTimezoneTextBox()).getAttribute("value");				
		serviceScheduleFields.put("ServiceOptions", serviceOptionsValue);
		serviceScheduleFields.put("arrivalWindowStart", arrivalWindowStartValue);
		serviceScheduleFields.put("timezone", timezoneValue);
		serviceScheduleFields.put("arrivalWindowEnd", arrivalWindowEndValue);
		
		Iterator<String> iterator_serviceSchedule = serviceScheduleFields.keySet().iterator();

	    while (iterator_serviceSchedule.hasNext()) {
	        String key =iterator_serviceSchedule.next();
	        String value=serviceScheduleFields.get(key);
	        if(value.equals("")){
		    	System.out.println(key+" is emty and no system returned values");
		    }
		    else{
		    	
		    	System.out.println("For "+key+"--> displayed attribute is : "+value);
		    }
	        
	        
	      }

		
		
		
		
	}
	

	public void validateDispatchAddressFields(WebDriver driver) throws Exception{
		
	}
	
	

	public void validatePrimaryContactFields(WebDriver driver) throws Exception{
		
	}

		
	// FSD Second Test Case
	

	public void alternateContact(WebDriver driver) throws Exception{
		
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);
		Thread.sleep(5000);
		driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactCheeseBox()).click();
		driver.findElement(obj_ReviewAndSubmitDispatchPage.OkBtnAlternateContact()).click();
		
	}

	
	
	
	public void DispatchCreation_PartsAndLabour(WebDriver driver, String serviceType, String partNumber)
	{
		try
		{
			//Thread.sleep(5000);
			WebDriverWait wait=new WebDriverWait(driver,150);
			System.out.println("Entered into DispatchCreation_BreakFix method..........");
			//Selecting Repeat Reason
			
			String repeatDispatch=driver.findElement(obj_ReviewAndSubmitDispatchPage.getrepeatDispatch()).getAttribute("value");
			   // String repeatDispatch=driver.findElement(By.xpath("//input[@aria-label='Repeat Dispatch']")).getAttribute("value");
			    System.out.println("repeatDispatch" +repeatDispatch);
			    int countRepeatOfrepeatDispatch=Integer.parseInt(repeatDispatch);
			    System.out.println("Repeat count"+countRepeatOfrepeatDispatch);
			    if(countRepeatOfrepeatDispatch>0){
					System.out.println("Entering Repeat Reason");
					driver.findElement(obj_ReviewAddressAndDetailsPage.txtRepeatReason()).sendKeys("Customer Availability");
					driver.findElement(obj_ReviewAddressAndDetailsPage.txtRepeatReason()).sendKeys(Keys.TAB);
			Thread.sleep(3000);
			    }
			    
			    
			    
			alternateContact(driver);
			System.out.println("Clicking on the Create Dispatch Button....");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
		   // wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
			System.out.println("Initiated creating dispatch");
		    driver.findElement(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()).click();
		    
		    ManullyAddressAndValidationPartsandLabor(driver,serviceType);
		    
		    
		    dispatchAddressValidation(driver);
		    primaryContactValidation(driver);
		    alternateContactValidation(driver);
		    serviceAttributeValidation(driver);
		    systemAttributeValidation(driver);
		    serviceScheduleValidation(driver);
		    
		    
		    
		    
		    
		    
		    
		    
		    SelectServiceType_ServiceOption(driver, serviceType);
		    
		    //createInstruction(driver,"Replace");
		    
		    //validating duplicate instruction
		    if(serviceType.contains("Parts and Labor")){
		    	createInstruction(driver,"Replace","DSP","Parts As Necessary");
		    	//Thread.sleep(1000);
		    	/*wait.until(ExpectedConditions.alertIsPresent());
		    	handleAlert(driver);*/
		    	driver.findElement(obj_ReviewAndSubmitDispatchPage.instructionDeleteButton()).click();
		    	Thread.sleep(1000);
		    	//wait.until(ExpectedConditions.alertIsPresent());
		    	handleAlert(driver);
		    	Thread.sleep(3000);
		    	
		    }
		    AddParts_LineItem(driver,partNumber);
		    
		    
		   
		    
		    Thread.sleep(5000);//8000
		    //Clicking on the Submit button in the page "Review Confirm Service Detail and Submit"
		    
		   // wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		    //obj_ReviewAndSubmitDispatchPage.getDispatchSubmit(driver).click();
		    //driver.findElement(obj_ReviewAndSubmitDispatchPage.submitButton()).click();
		    
		   // driver.findElement(By.xpath("//button [@aria-label='Next']")).click();
		    System.out.println("Clicking on next button");
		    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPage.nextButtonUnderSubmit()));
		    driver.findElement(obj_ReviewAndSubmitDispatchPage.nextButtonUnderSubmit()).click();
		    
		    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPage.submitButton()));
		    Thread.sleep(6000);//10000
		  //driver.findElement(By.xpath("//button[@aria-label='Submit']")).click();
		    System.out.println("Clicking on submit button");
		    driver.findElement(obj_ReviewAndSubmitDispatchPage.submitButton()).click();
		    //Fetching the dps number.....
		   /* String dpsNumber=obj_ReviewAndSubmitDispatchPage.fetchDispatchNumber(driver).getAttribute("value").trim();
		    String dpsStatus=obj_ReviewAndSubmitDispatchPage.fetchDispatchStatus(driver).getAttribute("value").trim();
		    String dpsSubStatus=obj_ReviewAndSubmitDispatchPage.fetchDispatchSubStatus(driver).getAttribute("value").trim();
		    String dpsRegion=obj_ReviewAndSubmitDispatchPage.fetchDispatchRegion(driver).getAttribute("value").trim();
		    String dpsBUID=obj_ReviewAndSubmitDispatchPage.fetchDispatchBUID(driver).getAttribute("value").trim();
		    System.out.println("dpsNumber:"+dpsNumber);*/
		    
		    String dpsNumber=driver.findElement(obj_ReviewAndSubmitDispatchPage.dpsNoUnderActivity()).getAttribute("value");
		    String dpsRegion=driver.findElement(obj_ReviewAndSubmitDispatchPage.regionUnderActivity()).getAttribute("value");
		    
		    
		   // String dpsNumber=driver.findElement(By.xpath("//input[@aria-label='DPS #']")).getAttribute("value");
		    //String dpsRegion=driver.findElement(obj_ReviewAndSubmitDispatchPage.regionUnderActivity()).getAttribute("value");
		    
		    
		    if(dpsNumber==null || dpsNumber=="" || dpsNumber.isEmpty())
		    {
		    	System.out.println("The Dispatch Number is: "+dpsNumber);
		    	System.out.println("Dispatch Creation Failed......");
		    	System.exit(1);
		    }
		    
		    System.out.println("Dispatch Created Successfully, The Dispatch Number is: "+dpsNumber);
		    
		    verifyDispatch(driver);
		    verifyAuditTrial(driver);
		    verifyDeltaDispatch(driver);
		    //System.out.println("Dispatch Created Successfully, The Dispatch Status is: "+dpsRegion);
		    /*System.out.println("Dispatch Created Successfully, The Dispatch SubStatus is: "+dpsSubStatus);
		    System.out.println("Dispatch Created Successfully, The Dispatch Region is: "+dpsRegion);
		    System.out.println("Dispatch Created Successfully, The Dispatch BUID is: "+dpsBUID);
		    System.out.println("Dispatch Created Successfully, The Service Type is: "+serviceType);
			*/
		    Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
		
	}
	
	
	
	public void ManullyAddressAndValidationPartsandLabor(WebDriver driver,String serviceType) throws Exception{
	    
		try{
			
		    driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		    WebDriverWait wait=new WebDriverWait(driver,150);
   		    //Thread.sleep(8000);//8000
			
   		    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()));
   		    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()));
			//driver.findElement(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()).sendKeys(testDataForTc_1358564.get("AddressLine1"));
			/*System.out.println("clearing address line 1  ");
			driver.findElement(obj_ReviewAddressAndDetailsPage.getAddressLine1TextBox()).clear();;*/
			Thread.sleep(3000);//5000
			
			//driver.findElement(By.xpath("//button[@aria-label='ISP Dispatch Address Asset Details:COPY >']")).click();
			
			driver.findElement(obj_ReviewAddressAndDetailsPage.CopyButton()).click();
			
			//driver.findElement(By.xpath("//button[@title='Address Validation:OK']")).click();
			driver.findElement(obj_ReviewAddressAndDetailsPage.getOkButtonOfAddessValidation()).click();

			try{
				
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("Alert Message displayed after clicking on Validate button:"+alert.getText());
				alert.accept();
				System.err.println("Error message");
				//System.exit(1);
			}
			catch(NoAlertPresentException e){
				//System.out.println("parts is avialable for the service tag");
			}
			
			WebElement doNotUpdateAssetCheckBoxElement=driver.findElement(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox());
			if(doNotUpdateAssetCheckBoxElement.isSelected())
			{
				
			}
			else{
				Thread.sleep(2000);
				System.out.println("clicking on do not update check box");
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox()));
				driver.findElement(obj_ReviewAddressAndDetailsPage.getDoNotUpdateAssetCheckBox()).click();
				Thread.sleep(2000);
				
			}
			
	        try{
				
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				System.out.println("Alert Message displayed after clicking on Validate button:"+alert.getText());
				alert.accept();
				System.err.println("Error message");
				//System.exit(1);
			}
			catch(NoAlertPresentException e){
				//System.out.println("parts is avialable for the service tag");
			}
			//if condition is closing
			/*System.out.println("clicking on ok button of address validation pop-up");
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getOkButtonOfAddessValidation()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getOkButtonOfAddessValidation()).click();
			Thread.sleep(10000);
			*/
	        
			
			System.out.println("clicking on Next button of ReviewAddressAndDetails screen");
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getNextButton()));
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getNextButton()));
			driver.findElement(obj_ReviewAddressAndDetailsPage.getNextButton()).click();
			//Thread.sleep(10000);//40000
			
			//wait.until(ExpectedConditions.alertIsPresent());
			try{
				
				Alert alert=driver.switchTo().alert();
				System.out.println("Switched to alert pop-up");
				
				OOwText=alert.getText();
				System.out.println("Alert Message displayed after clicking on Validate button:"+alert.getText());
				alert.accept();
				//System.err.println("Error message");
				//System.exit(1);
			}
			catch(NoAlertPresentException e){
				System.out.println("parts is avialable for the service tag");
			}
			
	        
			
			
			
			
		}
		catch(Exception e){
			System.out.println("Exception caught while executing the method in validationOnUpdateDispatchAddress "+e);
			e.printStackTrace();
		}
			
	}

	
	
	

	
	
	// Test Case one New code
	
	//UX Test Case Function
		public void Dispatch_OOW_B2DUX2(WebDriver driver, String Repeat, String ServiceType, String Category, String partNumber)
		{
			
			ReviewAndSubmitDispatchPageUX obj_ReviewAndSubmitDispatchPageUX=new ReviewAndSubmitDispatchPageUX();
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			WebDriverWait wait=new WebDriverWait(driver,150);
			
			try
			{
				System.out.println("Entered into Dispatch_OOW_B2D method..........");
				//Thread.sleep(5000);
				
				//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLeftPane()).isDisplayed();
				
				/*if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateLeftPane())).isDisplayed()){
					System.out.println("LeftPane is Displayed");
				}
				else{
					System.out.println("LeftPane is not Displayed");
				}
				
				if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateMiddlePane())).isDisplayed()){
					System.out.println("MiddlePane is Displayed");
				}
				else{
					System.out.println("MiddlePane is not Displayed");
				}
				
				if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateRightPane())).isDisplayed()){
					System.out.println("RightPane is Displayed");
				}
				else{
					System.out.println("RightPane is not Displayed");
				}*/
				
				
	/*			String MiddlePaneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateMiddlePane()).getAttribute("value");
				System.out.println("MiddlePane value is:"+MiddlePaneValue);
				
				String RightPaneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateRightPane()).getAttribute("value");
				System.out.println("RightPane value is:"+RightPaneValue);*/
				
				/*String DisFirstNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisFirstName()).getAttribute("value");
				System.out.println("Dispatch First Name is:"+DisFirstNameValue);
				
				String DisLastNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisLastName()).getAttribute("value");
				System.out.println("Dispatch Last Name is:"+DisLastNameValue);
				
				String DisPhoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhone()).getAttribute("value");
				System.out.println("Dispatch Phone Number is:"+DisPhoneValue);
				
				String DisPhoneExtenValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhoneExten()).getAttribute("value");
				System.out.println("Dispatch Phone Extension is:"+DisPhoneExtenValue);
				
				String DisEmailValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisEmail()).getAttribute("value");
				System.out.println("Dispatch Email is:"+DisEmailValue);*/
				
				/*String ContactAccordValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateContactAccord()).getAttribute("value");
				System.out.println("Contact Accord value is:"+ContactAccordValue);*/
				
				/*String CustomerNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCustomerName()).getAttribute("value");
				System.out.println("Customer Name is:"+CustomerNameValue);
				
				String DisAddressLine1Value=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisAddressLine1()).getAttribute("value");
				System.out.println("Address Line1 value is:"+DisAddressLine1Value);
				
				String DisCountryValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisCountry()).getAttribute("value");
				System.out.println("Dispatch Country is:"+DisCountryValue);
				
				String DisPostalValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidataDisPostal()).getAttribute("value");
				System.out.println("Dispatch Postal Code is:"+DisPostalValue);*/
				
	/*			String CurrentEntitlementValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCurrentEntitlement()).getAttribute("value");
				System.out.println("Current Entitlement value is:"+CurrentEntitlementValue);
				
				String LocationCoverageValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLocationCoverage()).getAttribute("value");
				System.out.println("Location Coverage value is:"+LocationCoverageValue);
				
				String ServiceTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceType()).getAttribute("value");
				System.out.println("ServiceType is:"+ServiceTypeValue);
				
				String EntitlementStartValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementStart()).getAttribute("value");
				System.out.println("EntitlementStart value is:"+EntitlementStartValue);
				
				String txtValidateEntitlementEndValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementEnd()).getAttribute("value");
				System.out.println("txtValidateEntitlementEnd value is:"+txtValidateEntitlementEndValue);
				
				String ProductDescValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateProductDesc()).getAttribute("value");
				System.out.println("ProductDesc value is:"+ProductDescValue);*/
				
				/*String ReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateReceiver()).getAttribute("value");
				System.out.println("Receiver value is:"+ReceiverValue);
				
				String TypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateType()).getAttribute("value");
				System.out.println("Type value is:"+TypeValue);
				
				String InstructionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateInstruction()).getAttribute("value");
				System.out.println("Instruction value is:"+InstructionValue);*/
				
				/*String ServiceOptionsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceOptions()).getAttribute("value");
				System.out.println("Service Options value is:"+ServiceOptionsValue);*/
				
				/*String PartFunctionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidatePartFunction()).getAttribute("value");
				System.out.println("Part Function value is:"+PartFunctionValue);
				
				String SelectedPartsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateSelectedParts()).getAttribute("value");
				System.out.println("Selected Parts value is:"+SelectedPartsValue);*/
				
				/*String NewInstructionTextValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionText()).getAttribute("value");
				System.out.println("New Instruction Text value is:"+NewInstructionTextValue);
				
				String NewInstructionReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionReceiver()).getAttribute("value");
				System.out.println("New Instruction Receiver value is:"+NewInstructionReceiverValue);
				
				String NewInstructionTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionType()).getAttribute("value");
				System.out.println("New Instruction Type value is:"+NewInstructionTypeValue);
				
				String NewInstructionCreatedValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreated()).getAttribute("value");
				System.out.println("New Instruction Created value is:"+NewInstructionCreatedValue);
				
				String NewInstructionCreatedByValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreatedBy()).getAttribute("value");
				System.out.println("New Instruction CreatedByNew Instruction Receiver value is:"+NewInstructionCreatedByValue);
				
				String NewStatusValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewStatus()).getAttribute("value");
				System.out.println("New Status value is:"+NewStatusValue);*/
				
				
				//Selecting Repeat Reason
				System.out.println("Entering Repeat Reason");
				//wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()));
				//wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys("Incorrect Diagnostics");
				
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys(Repeat);
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys(Keys.TAB);
				
	/*			driver.findElement(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()).sendKeys("Incorrect Diagnostics");
				driver.findElement(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()).sendKeys(Keys.TAB);*/
				//Thread.sleep(3000);
				
				String DisFirstNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisFirstName()).getAttribute("value");
				System.out.println("Dispatch First Name is:"+DisFirstNameValue);
				
				String DisLastNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisLastName()).getAttribute("value");
				System.out.println("Dispatch Last Name is:"+DisLastNameValue);
				
				String DisPhoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhone()).getAttribute("value");
				System.out.println("Dispatch Phone Number is:"+DisPhoneValue);
				
				String DisPhoneExtenValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhoneExten()).getAttribute("value");
				System.out.println("Dispatch Phone Extension is:"+DisPhoneExtenValue);
				
				String DisEmailValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisEmail()).getAttribute("value");
				System.out.println("Dispatch Email is:"+DisEmailValue);
				
				System.out.println("Clicking on the NoAlternateContactCheckBox....");
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.noAlternateContactCheckBox())).click();
				//driver.findElement(obj_ReviewAddressAndDetailsPageUX.noAlternateContactCheckBox()).click();
			   
				System.out.println("clicking on NewtDispatchNextButton " );
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.confirmContactNextButton())).click();
			    //driver.findElement(obj_ReviewAddressAndDetailsPageUX.confirmContactNextButton()).click();
			    //Thread.sleep(5000);
				
				String CustomerNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCustomerName()).getText();
				System.out.println("Customer Name is:"+CustomerNameValue);
				
				String DisAddressLine1Value=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisAddressLine1()).getText();
				System.out.println("Address Line1 value is:"+DisAddressLine1Value);
				
				String DisCountryValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisCountry()).getAttribute("value");
				System.out.println("Dispatch Country is:"+DisCountryValue);
				
				String DisPostalValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidataDisPostal()).getAttribute("value");
				System.out.println("Dispatch Postal Code is:"+DisPostalValue);
			    
			    System.out.println("clicking on AddressValidationNextButton" );
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton())).click();
			    
			   /* wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton()));
			    driver.findElement(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton()).click();*/
			   
			//    System.out.println("waiting for alert");
			  //  wait.until(ExpectedConditions.alertIsPresent());
			    //handleAlert(driver);
			    //Thread.sleep(4000);
			    
			    SelectServiceType_ServiceOptionUx2(driver,ServiceType,Category);
			    
			   /* if(serviceType.contains("Parts and Labour")){
			    alertManualDispatch(driver);
			    handleAlert(driver);
			    }
			   */ 
			   // System.out.println("Clicking on instruction next button");
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton()).click();
			   
			 
			    System.out.println("Clicking on Next button of Instruction" );
			    //Thread.sleep(10000);
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton())).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton()).click();
			   
			    System.out.println("Handle me manually");
			    
			    Thread.sleep(10000);
			    
			 
			    System.out.println("Clicking on ManualPartLink" );
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.manualPartLink())).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.manualPartLink()).click();
			    //Thread.sleep(10000);
			    
	/*		    if(serviceType.contains("Parts and Labour")){
			    	System.out.println("I entered into this IF LOOP");
				    alertManualDispatch(driver);
				    Thread.sleep(10000);
				    handleAlert(driver);
				    }*/
			   
			    
			    System.out.println("Entering Part no" );
			   // Thread.sleep(10000);
			    /*wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()));
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()));
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()).sendKeys("21TUG");
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo())).sendKeys(partNumber);
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo())).sendKeys(Keys.TAB);
			    
			    
			    System.out.println("Clicking on Part no search icon" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.searchPPidImg()).click();
			    //Thread.sleep(4000);
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.searchPPidImg())).click();
			    
			    System.out.println("Clicking on the PPID Image + button");
			    
			    System.out.println("Clicking on Add Part plus icon" );
			    //Thread.sleep(10000);
			    //driver.findElement(By.xpath("//*[@id='0_21TUG']/div[2]/div[1]/div[2]/i")).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnplusIconforAddParts()).click();
			    //Thread.sleep(8000);
			    
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnplusIconforAddParts())).click();
			    
			    String PartFunctionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidatePartFunction()).getAttribute("value");
				System.out.println("Part Function value is:"+PartFunctionValue);
				
				String SelectedPartsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateSelectedParts()).getAttribute("value");
				System.out.println("Selected Parts value is:"+SelectedPartsValue);
				
				/*wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnDispatchOption())).click();
				
				SelectServiceType_ServiceOptionUx(driver,ServiceType,Category,Billto);
				
				String NewInstructionTextValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionText()).getAttribute("value");
				System.out.println("New Instruction Text value is:"+NewInstructionTextValue);
				
				String NewInstructionReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionReceiver()).getAttribute("value");
				System.out.println("New Instruction Receiver value is:"+NewInstructionReceiverValue);
				
				String NewInstructionTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionType()).getAttribute("value");
				System.out.println("New Instruction Type value is:"+NewInstructionTypeValue);
				
				String NewInstructionCreatedValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreated()).getAttribute("value");
				System.out.println("New Instruction Created value is:"+NewInstructionCreatedValue);
				
				String NewInstructionCreatedByValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreatedBy()).getAttribute("value");
				System.out.println("New Instruction CreatedByNew Instruction Receiver value is:"+NewInstructionCreatedByValue);
				
				String NewStatusValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewStatus()).getAttribute("value");
				System.out.println("New Status value is:"+NewStatusValue);*/
				
				//SelectServiceType_ServiceOptionUx(driver,ServiceType,Category,Billto);
			    
	/*		    System.out.println("executing alert manual method" );
			    alertManualDispatch(driver);
			    Thread.sleep(3000);*/
			    
			   // System.out.println("Clicking on end dispatch button" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.EndDispatchButton()).click();
			    //Thread.sleep(3000);
			    
			    Thread.sleep(8000);
			    
			    System.out.println("I am here now");
			    
			    
			    System.out.println("Clicking on Auto Parts Icon" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnAutoPartLink()).click();
			    Thread.sleep(4000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnAutoPartLink())).click();
			    
	/*		    System.out.println("Clicking on Proceed and scheduling" );
			    Thread.sleep(10000);
			    driver.findElement(By.xpath("//button[@aria-label='Search Parts:Proceed To Scheduling']")).click();*/
			    
			    System.out.println("Clicking on Proceed and scheduling" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnScheduling()).click();
			    Thread.sleep(10000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnScheduling())).click();
			    
			    System.out.println("Checking on Alert Checkbox" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.LastalertCheckBox()).click();
			    Thread.sleep(10000);
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.LastalertCheckBox())).click();
			    
			    Thread.sleep(3000);
			    
			    System.out.println("Clicking on Dispatch button" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(15000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch())).click();
			    
	/*		    System.out.println("Clicking on Service Request Number" );
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(10000);
			    
			    System.out.println("Validating BreakFix Activity" );
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(10000);*/
			    
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.dispathchNo()));
			    WebElement DspNo=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.dispathchNo());
			    
			    if(DspNo.isDisplayed()){
			    	System.out.println("Dsp no:"+DspNo.getAttribute("value"));
			    	System.out.println("Dispatch creation successful");
			    	
			    	
			    }
			    else{
			    	System.out.println("Dispatch creation failed");
			    }
			    
			    
			    if(ServiceType.contains("Parts and Labour")){
		    	    
			    	 if(DspNo.isDisplayed()){
			    	System.out.println("Clicking on service no" );
			    	/*Thread.sleep(10000);
				    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.lnkServiceReqNumber()).click();
				    Thread.sleep(15000);*/
			    	
			    	wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.lnkServiceReqNumber())).click();
			    	
		 		    WebElement BreakFix=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtBreakFixAtActivity());
			    	
		 		    System.out.println("Break fix checking");
		 		    if(BreakFix.isDisplayed()){
		 		    System.out.println("break fix");
		 		    System.out.println("Break fix details"+BreakFix.getText());
		 		    }
			    	
			    }}
			       
			    
			}
			catch(Exception e)
			{
				System.out.println("Caught exception while executing Dispatch_OOW_B2D "+e);
				e.printStackTrace();
				
			}
			
		}
		
		
		/// 2 nd Test Case
		
		public void Dispatch_OOW_B2DUX(WebDriver driver, String Repeat, String ServiceType, String Category, String Billto, String partNumber)
		{
			
			ReviewAndSubmitDispatchPageUX obj_ReviewAndSubmitDispatchPageUX=new ReviewAndSubmitDispatchPageUX();
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			WebDriverWait wait=new WebDriverWait(driver,150);
			
			try
			{
				System.out.println("Entered into Dispatch_OOW_B2D method..........");
				//Thread.sleep(5000);
				
				//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLeftPane()).isDisplayed();
				
				/*if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateLeftPane())).isDisplayed()){
					System.out.println("LeftPane is Displayed");
				}
				else{
					System.out.println("LeftPane is not Displayed");
				}
				
				if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateMiddlePane())).isDisplayed()){
					System.out.println("MiddlePane is Displayed");
				}
				else{
					System.out.println("MiddlePane is not Displayed");
				}
				
				if(wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtValidateRightPane())).isDisplayed()){
					System.out.println("RightPane is Displayed");
				}
				else{
					System.out.println("RightPane is not Displayed");
				}*/
				
				
	/*			String MiddlePaneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateMiddlePane()).getAttribute("value");
				System.out.println("MiddlePane value is:"+MiddlePaneValue);
				
				String RightPaneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateRightPane()).getAttribute("value");
				System.out.println("RightPane value is:"+RightPaneValue);*/
				
				/*String DisFirstNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisFirstName()).getAttribute("value");
				System.out.println("Dispatch First Name is:"+DisFirstNameValue);
				
				String DisLastNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisLastName()).getAttribute("value");
				System.out.println("Dispatch Last Name is:"+DisLastNameValue);
				
				String DisPhoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhone()).getAttribute("value");
				System.out.println("Dispatch Phone Number is:"+DisPhoneValue);
				
				String DisPhoneExtenValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhoneExten()).getAttribute("value");
				System.out.println("Dispatch Phone Extension is:"+DisPhoneExtenValue);
				
				String DisEmailValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisEmail()).getAttribute("value");
				System.out.println("Dispatch Email is:"+DisEmailValue);*/
				
				/*String ContactAccordValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateContactAccord()).getAttribute("value");
				System.out.println("Contact Accord value is:"+ContactAccordValue);*/
				
				/*String CustomerNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCustomerName()).getAttribute("value");
				System.out.println("Customer Name is:"+CustomerNameValue);
				
				String DisAddressLine1Value=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisAddressLine1()).getAttribute("value");
				System.out.println("Address Line1 value is:"+DisAddressLine1Value);
				
				String DisCountryValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisCountry()).getAttribute("value");
				System.out.println("Dispatch Country is:"+DisCountryValue);
				
				String DisPostalValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidataDisPostal()).getAttribute("value");
				System.out.println("Dispatch Postal Code is:"+DisPostalValue);*/
				
	/*			String CurrentEntitlementValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCurrentEntitlement()).getAttribute("value");
				System.out.println("Current Entitlement value is:"+CurrentEntitlementValue);
				
				String LocationCoverageValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLocationCoverage()).getAttribute("value");
				System.out.println("Location Coverage value is:"+LocationCoverageValue);
				
				String ServiceTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceType()).getAttribute("value");
				System.out.println("ServiceType is:"+ServiceTypeValue);
				
				String EntitlementStartValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementStart()).getAttribute("value");
				System.out.println("EntitlementStart value is:"+EntitlementStartValue);
				
				String txtValidateEntitlementEndValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementEnd()).getAttribute("value");
				System.out.println("txtValidateEntitlementEnd value is:"+txtValidateEntitlementEndValue);
				
				String ProductDescValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateProductDesc()).getAttribute("value");
				System.out.println("ProductDesc value is:"+ProductDescValue);*/
				
				/*String ReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateReceiver()).getAttribute("value");
				System.out.println("Receiver value is:"+ReceiverValue);
				
				String TypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateType()).getAttribute("value");
				System.out.println("Type value is:"+TypeValue);
				
				String InstructionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateInstruction()).getAttribute("value");
				System.out.println("Instruction value is:"+InstructionValue);*/
				
				/*String ServiceOptionsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceOptions()).getAttribute("value");
				System.out.println("Service Options value is:"+ServiceOptionsValue);*/
				
				/*String PartFunctionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidatePartFunction()).getAttribute("value");
				System.out.println("Part Function value is:"+PartFunctionValue);
				
				String SelectedPartsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateSelectedParts()).getAttribute("value");
				System.out.println("Selected Parts value is:"+SelectedPartsValue);*/
				
				/*String NewInstructionTextValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionText()).getAttribute("value");
				System.out.println("New Instruction Text value is:"+NewInstructionTextValue);
				
				String NewInstructionReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionReceiver()).getAttribute("value");
				System.out.println("New Instruction Receiver value is:"+NewInstructionReceiverValue);
				
				String NewInstructionTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionType()).getAttribute("value");
				System.out.println("New Instruction Type value is:"+NewInstructionTypeValue);
				
				String NewInstructionCreatedValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreated()).getAttribute("value");
				System.out.println("New Instruction Created value is:"+NewInstructionCreatedValue);
				
				String NewInstructionCreatedByValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreatedBy()).getAttribute("value");
				System.out.println("New Instruction CreatedByNew Instruction Receiver value is:"+NewInstructionCreatedByValue);
				
				String NewStatusValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewStatus()).getAttribute("value");
				System.out.println("New Status value is:"+NewStatusValue);*/
				
				
				//Selecting Repeat Reason
				System.out.println("Entering Repeat Reason");
				//wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()));
				//wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys("Incorrect Diagnostics");
				
				Thread.sleep(5000);
				
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys(Repeat);
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox())).sendKeys(Keys.TAB);
				
	/*			driver.findElement(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()).sendKeys("Incorrect Diagnostics");
				driver.findElement(obj_ReviewAddressAndDetailsPageUX.repeatReasonTextbox()).sendKeys(Keys.TAB);*/
				//Thread.sleep(3000);
				
				String DisFirstNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisFirstName()).getAttribute("value");
				System.out.println("Dispatch First Name is:"+DisFirstNameValue);
				
				String DisLastNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisLastName()).getAttribute("value");
				System.out.println("Dispatch Last Name is:"+DisLastNameValue);
				
				String DisPhoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhone()).getAttribute("value");
				System.out.println("Dispatch Phone Number is:"+DisPhoneValue);
				
				String DisPhoneExtenValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhoneExten()).getAttribute("value");
				System.out.println("Dispatch Phone Extension is:"+DisPhoneExtenValue);
				
				String DisEmailValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisEmail()).getAttribute("value");
				System.out.println("Dispatch Email is:"+DisEmailValue);
				
				System.out.println("Clicking on the NoAlternateContactCheckBox....");
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.noAlternateContactCheckBox())).click();
				//driver.findElement(obj_ReviewAddressAndDetailsPageUX.noAlternateContactCheckBox()).click();
			   
				System.out.println("clicking on NewtDispatchNextButton " );
				wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.confirmContactNextButton())).click();
			    //driver.findElement(obj_ReviewAddressAndDetailsPageUX.confirmContactNextButton()).click();
			    //Thread.sleep(5000);
				
				String CustomerNameValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCustomerName()).getText();
				System.out.println("Customer Name is:"+CustomerNameValue);
				
				String DisAddressLine1Value=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisAddressLine1()).getText();
				System.out.println("Address Line1 value is:"+DisAddressLine1Value);
				
				String DisCountryValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisCountry()).getAttribute("value");
				System.out.println("Dispatch Country is:"+DisCountryValue);
				
				String DisPostalValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidataDisPostal()).getAttribute("value");
				System.out.println("Dispatch Postal Code is:"+DisPostalValue);
			    
			    System.out.println("clicking on AddressValidationNextButton" );
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton())).click();
			    
			   /* wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton()));
			    driver.findElement(obj_ReviewAddressAndDetailsPageUX.addressValidationNextButton()).click();*/
			   
			    System.out.println("waiting for alert");
			    wait.until(ExpectedConditions.alertIsPresent());
			    handleAlert(driver);
			    //Thread.sleep(4000);
			    
			    SelectServiceType_ServiceOptionUx(driver,ServiceType,Category,Billto);
			    
			   /* if(serviceType.contains("Parts and Labour")){
			    alertManualDispatch(driver);
			    handleAlert(driver);
			    }
			   */ 
			   // System.out.println("Clicking on instruction next button");
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton()).click();
			   
			 
			    System.out.println("Clicking on Next button of Instruction" );
			    //Thread.sleep(10000);
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton())).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton()).click();
			   
			    Thread.sleep(5000);
			    
			 
			    System.out.println("Clicking on ManualPartLink" );
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.manualPartLink())).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.manualPartLink()).click();
			    //Thread.sleep(10000);
			    
	/*		    if(serviceType.contains("Parts and Labour")){
			    	System.out.println("I entered into this IF LOOP");
				    alertManualDispatch(driver);
				    Thread.sleep(10000);
				    handleAlert(driver);
				    }*/
			   
			    
			    System.out.println("Entering Part no" );
			   // Thread.sleep(10000);
			    /*wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()));
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()));
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()).sendKeys("21TUG");
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.PPIdNo()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo())).sendKeys(partNumber);
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.PPIdNo())).sendKeys(Keys.TAB);
			    
			    
			    System.out.println("Clicking on Part no search icon" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.searchPPidImg()).click();
			    //Thread.sleep(4000);
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.searchPPidImg())).click();
			    
			    System.out.println("Clicking on the PPID Image + button");
			    
			    System.out.println("Clicking on Add Part plus icon" );
			    //Thread.sleep(10000);
			    //driver.findElement(By.xpath("//*[@id='0_21TUG']/div[2]/div[1]/div[2]/i")).click();
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnplusIconforAddParts()).click();
			    //Thread.sleep(8000);
			    
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnplusIconforAddParts())).click();
			    
			    String PartFunctionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidatePartFunction()).getAttribute("value");
				System.out.println("Part Function value is:"+PartFunctionValue);
				
				String SelectedPartsValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateSelectedParts()).getAttribute("value");
				System.out.println("Selected Parts value is:"+SelectedPartsValue);
				
				/*wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnDispatchOption())).click();
				
				SelectServiceType_ServiceOptionUx(driver,ServiceType,Category,Billto);
				
				String NewInstructionTextValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionText()).getAttribute("value");
				System.out.println("New Instruction Text value is:"+NewInstructionTextValue);
				
				String NewInstructionReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionReceiver()).getAttribute("value");
				System.out.println("New Instruction Receiver value is:"+NewInstructionReceiverValue);
				
				String NewInstructionTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionType()).getAttribute("value");
				System.out.println("New Instruction Type value is:"+NewInstructionTypeValue);
				
				String NewInstructionCreatedValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreated()).getAttribute("value");
				System.out.println("New Instruction Created value is:"+NewInstructionCreatedValue);
				
				String NewInstructionCreatedByValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewInstructionCreatedBy()).getAttribute("value");
				System.out.println("New Instruction CreatedByNew Instruction Receiver value is:"+NewInstructionCreatedByValue);
				
				String NewStatusValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateNewStatus()).getAttribute("value");
				System.out.println("New Status value is:"+NewStatusValue);*/
				
				//SelectServiceType_ServiceOptionUx(driver,ServiceType,Category,Billto);
			    
	/*		    System.out.println("executing alert manual method" );
			    alertManualDispatch(driver);
			    Thread.sleep(3000);*/
			    
			   // System.out.println("Clicking on end dispatch button" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.EndDispatchButton()).click();
			    //Thread.sleep(3000);
			    
			    Thread.sleep(8000);
			    
			    System.out.println("I am here now");
			    
			    
			    System.out.println("Clicking on Auto Parts Icon" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnAutoPartLink()).click();
			    Thread.sleep(4000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnAutoPartLink())).click();
			    
	/*		    System.out.println("Clicking on Proceed and scheduling" );
			    Thread.sleep(10000);
			    driver.findElement(By.xpath("//button[@aria-label='Search Parts:Proceed To Scheduling']")).click();*/
			    
			    System.out.println("Clicking on Proceed and scheduling" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnScheduling()).click();
			    Thread.sleep(10000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnScheduling())).click();
			    
			    System.out.println("Checking on Alert Checkbox" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.LastalertCheckBox()).click();
			    Thread.sleep(10000);
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.LastalertCheckBox())).click();
			    
			    Thread.sleep(3000);
			    
			    System.out.println("Clicking on Dispatch button" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(15000);*/
			    
			    wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch())).click();
			    
	/*		    System.out.println("Clicking on Service Request Number" );
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(10000);
			    
			    System.out.println("Validating BreakFix Activity" );
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.btnLastDispatch()).click();
			    Thread.sleep(10000);*/
			    
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.dispathchNo()));
			    WebElement DspNo=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.dispathchNo());
			    
			    if(DspNo.isDisplayed()){
			    	System.out.println("Dsp no:"+DspNo.getAttribute("value"));
			    	System.out.println("Dispatch creation successful");
			    	
			    	
			    }
			    else{
			    	System.out.println("Dispatch creation failed");
			    }
			    
			    
			    if(ServiceType.contains("Parts and Labour")){
		    	    
			    	 if(DspNo.isDisplayed()){
			    	System.out.println("Clicking on service no" );
			    	/*Thread.sleep(10000);
				    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.lnkServiceReqNumber()).click();
				    Thread.sleep(15000);*/
			    	
			    	wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.lnkServiceReqNumber())).click();
			    	
		 		    WebElement BreakFix=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtBreakFixAtActivity());
			    	
		 		    System.out.println("Break fix checking");
		 		    if(BreakFix.isDisplayed()){
		 		    System.out.println("break fix");
		 		    System.out.println("Break fix details"+BreakFix.getText());
		 		    }
			    	
			    }}
			       
			    
			}
			catch(Exception e)
			{
				System.out.println("Caught exception while executing Dispatch_OOW_B2D "+e);
				e.printStackTrace();
				
			}
			
		}
		
		
		
		public void SelectServiceType_ServiceOptionUx(WebDriver driver, String ServiceType, String Category, String Billto){
			
			WebDriverWait wait=new WebDriverWait(driver,150);
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			try{
			
				System.out.println("Checking show more options" );
				WebElement showChckBx=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.showMoreOptionsCheckBox());
				
				if(showChckBx.isSelected()){
				
				Thread.sleep(6000);
			    System.out.println("entering text into service type" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).clear();
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).clear();
			    
			    //Thread.sleep(2000);
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).sendKeys("Collect and Return");
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).sendKeys(ServiceType);
			    
				//Thread.sleep(3000);
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).sendKeys(Keys.TAB);
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).sendKeys(Keys.TAB);
			    
				    
			    System.out.println("entering text into category" );
			    /*driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys("001 - Collection with Box");
			    Thread.sleep(4000);
			    driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Category);
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Keys.TAB);
			    
			    System.out.println("entering text into BilltoField" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField()).sendKeys("Ongoing supporting issue");
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField())).sendKeys(Billto);
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField())).sendKeys(Keys.TAB);
			    
				String CurrentEntitlementValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCurrentEntitlement()).getAttribute("value");
				System.out.println("Current Entitlement value is:"+CurrentEntitlementValue);
				
				String LocationCoverageValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLocationCoverage()).getAttribute("value");
				System.out.println("Location Coverage value is:"+LocationCoverageValue);
				
				String ServiceTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceType()).getAttribute("value");
				System.out.println("ServiceType is:"+ServiceTypeValue);
				
				String EntitlementStartValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementStart()).getAttribute("value");
				System.out.println("EntitlementStart value is:"+EntitlementStartValue);
				
				String txtValidateEntitlementEndValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementEnd()).getAttribute("value");
				System.out.println("txtValidateEntitlementEnd value is:"+txtValidateEntitlementEndValue);
				
				String ProductDescValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateProductDesc()).getAttribute("value");
				System.out.println("ProductDesc value is:"+ProductDescValue);
			    
				}
				else{
					System.out.println("Clicking on show more options check box" );
					showChckBx.click();
					//Thread.sleep(3000);
					
				    System.out.println("entering text into category" );
				    /*driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys("PWS-Parts and Labor");
				    Thread.sleep(4000);
				    driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys(Keys.TAB);
				    
				    Thread.sleep(3000);*/
				    
				    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys("PWS-Parts and Labor");
				    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Keys.TAB);
				    
					/*instructionUx(driver);*/
				}
			
		    
			}
			catch(Exception e){
				System.out.println("caught exception while executing SelectServiceType_ServiceOptionUx method"+e);
			}
			
			}
		
public void SelectServiceType_ServiceOptionUx2(WebDriver driver, String ServiceType, String Category){
			
			WebDriverWait wait=new WebDriverWait(driver,150);
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			try{
			
				System.out.println("Checking show more options" );
				WebElement showChckBx=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.showMoreOptionsCheckBox());
				
				if(showChckBx.isSelected()){
				
				Thread.sleep(6000);
			    System.out.println("entering text into service type" );
			    //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).clear();
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).clear();
			    
			    //Thread.sleep(2000);
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).sendKeys("Collect and Return");
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).sendKeys(ServiceType);
			    
				//Thread.sleep(3000);
				//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx()).sendKeys(Keys.TAB);
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtserviceTypeUx())).sendKeys(Keys.TAB);
			    
				    
			    System.out.println("entering text into category" );
			    /*driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys("001 - Collection with Box");
			    Thread.sleep(4000);
			    driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Category);
			    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Keys.TAB);
			    
			    //System.out.println("entering text into BilltoField" );
	/*		    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField()).sendKeys("Ongoing supporting issue");
			    driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField()).sendKeys(Keys.TAB);
			    Thread.sleep(3000);*/
			    
			   // wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField())).sendKeys(Billto);
			   // wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.txtbilltoField())).sendKeys(Keys.TAB);
			    
				String CurrentEntitlementValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateCurrentEntitlement()).getAttribute("value");
				System.out.println("Current Entitlement value is:"+CurrentEntitlementValue);
				
				String LocationCoverageValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateLocationCoverage()).getAttribute("value");
				System.out.println("Location Coverage value is:"+LocationCoverageValue);
				
				String ServiceTypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateServiceType()).getAttribute("value");
				System.out.println("ServiceType is:"+ServiceTypeValue);
				
				String EntitlementStartValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementStart()).getAttribute("value");
				System.out.println("EntitlementStart value is:"+EntitlementStartValue);
				
				String txtValidateEntitlementEndValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateEntitlementEnd()).getAttribute("value");
				System.out.println("txtValidateEntitlementEnd value is:"+txtValidateEntitlementEndValue);
				
				String ProductDescValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateProductDesc()).getAttribute("value");
				System.out.println("ProductDesc value is:"+ProductDescValue);
			    
				}
				else{
					System.out.println("Clicking on show more options check box" );
					showChckBx.click();
					//Thread.sleep(3000);
					
				    System.out.println("entering text into category" );
				    /*driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys("PWS-Parts and Labor");
				    Thread.sleep(4000);
				    driver.findElement(obj_ReviewAddressAndDetailsPageUX.dispatchCategory()).sendKeys(Keys.TAB);
				    
				    Thread.sleep(3000);*/
				    
				    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys("PWS-Parts and Labor");
				    wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPageUX.dispatchCategory())).sendKeys(Keys.TAB);
				    
					/*instructionUx(driver);*/
				}
			
		    
			}
			catch(Exception e){
				System.out.println("caught exception while executing SelectServiceType_ServiceOptionUx method"+e);
			}
			
			}
		
		public void instructionUx(WebDriver driver){
			
			WebDriverWait wait=new WebDriverWait(driver,150);
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			
			try{
				
			/* Thread.sleep(4000);
			 System.out.println("entered into text instructionUx" );
			 driver.findElement(obj_ReviewAndSubmitDispatchPageUX.InstructionNewButton()).click();
			 Thread.sleep(5000);*/
				
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.InstructionNewButton())).click();
			 
			 System.out.println("entering data into receiver field" );
	/*		 driver.findElement(obj_ReviewAndSubmitDispatchPageUX.ReceiverList()).sendKeys("Replace");
			 driver.findElement(obj_ReviewAndSubmitDispatchPageUX.ReceiverList()).sendKeys(Keys.TAB);*/
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.ReceiverList())).sendKeys("Replace");
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.ReceiverList())).sendKeys(Keys.TAB);
			 
			 System.out.println("entering data into instruction type field" );
	/*		 driver.findElement(obj_ReviewAndSubmitDispatchPageUX.InstructionType()).sendKeys("DSP");
			 driver.findElement(obj_ReviewAndSubmitDispatchPageUX.ReceiverList()).sendKeys(Keys.TAB);*/
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.InstructionType())).sendKeys("DSP");
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.InstructionType())).sendKeys(Keys.TAB);
			 
			 System.out.println("click on next button" );
			 //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton()).click();
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.instructionNextButton())).click();
			 
			 System.out.println("waiting for alert" ); 
			 wait.until(ExpectedConditions.alertIsPresent());
			 handleAlert(driver);
			  
			 
			 System.out.println("clicking on delete button" );
			 //driver.findElement(obj_ReviewAndSubmitDispatchPageUX.InstructionsDeleteButton()).click();
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.InstructionsDeleteButton())).click();
			 
			 System.out.println("waiting for alert" ); 
			 wait.until(ExpectedConditions.alertIsPresent());
			 handleAlert(driver);
			 
			 String ReceiverValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateReceiver()).getAttribute("value");
				System.out.println("Receiver value is:"+ReceiverValue);
				
				String TypeValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateType()).getAttribute("value");
				System.out.println("Type value is:"+TypeValue);
				
				String InstructionValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateInstruction()).getAttribute("value");
				System.out.println("Instruction value is:"+InstructionValue);
			 
			
			 }
			 catch(Exception e){
				 System.out.println("caught exception while executing instructionUx method"+e);
				 e.printStackTrace();
			 }
			
		}

	
	
	public void alertManualDispatch(WebDriver driver){

		WebDriverWait wait=new WebDriverWait(driver,150);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		try{
			System.out.println("click on next button" );
			
			//wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAndSubmitDispatchPageUX.alertCheckBox()));
		    //wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAndSubmitDispatchPageUX.alertCheckBox()));
			//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.alertCheckBox()).click();
			Thread.sleep(10000);
			driver.findElement(By.xpath("//*[@id='a_1']/div[3]/div[2]/div[1]/input")).click();
			//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@title='Contacts:Dispatch']")));
		    //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Contacts:Dispatch']")));
			System.out.println("click on next Dispatch button" );
			System.out.println("check on the Ack button" );
			Thread.sleep(10000);
			driver.findElement(By.xpath("//button[@title='Contacts:Dispatch']")).click();
			System.out.println("Clicked on the Dispatch Button");
			//driver.findElement(obj_ReviewAndSubmitDispatchPageUX.EndDispatchButton()).click();
			
			
		}
		catch(Exception e){
			 System.out.println("caught exception while executing instructionUx method"+e);
			 e.printStackTrace();
		}
	
		
	}
	
	public void handleAlert(WebDriver driver){
	 try{
			System.out.println("switched to alert");
			Alert alert=driver.switchTo().alert();
			
			System.out.println("Alert Message displayed:"+alert.getText());
			
			alert.accept();
			
			
		}
		catch(NoAlertPresentException e){
			//System.out.println("parts is avialable for the service tag");
		}
	
	}
		
	//------------------------------------------field validation--------------------------------------
	
	
	
	public void dispatchAddressValidation(WebDriver driver) {

		try{	
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String c1="AddressLine1:SDNDN";
		 String c2="AddressLine1:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.addressLine1TextBox()).getAttribute("value");


		 String d1="City:BUCLOC";
		 String d2="City:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.cityTextBox()).getAttribute("value");
		 

		 String e1="State/County:TX";
		 String e2="State/County:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.stateCountyTextBox()).getAttribute("value");

		 System.out.println(e1+" "+e2);

		 String f1="Country:USA";
		 String f2="Country:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.countryTextBox()).getAttribute("value");
		
		

		 String f3="Postal Code:78005";
		 String f4="Postal Code:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.postalCode() ).getAttribute("value");

		 String[] elementsHardCode={c1,d1,e1,f1,f3};
		 String[] elementsDynamic={c2,d2,e2,f2,f4};
		 int i;
		 for(i=0;i<elementsHardCode.length;i++){
			if(verification(elementsHardCode[i],elementsDynamic[i])==1)
			continue;
			else
			System.out.println("Values are not as expected");
			
			break;
			
		 }
		 if(i==4){
			System.out.println("All Values are as expected");
		 }
		}catch(Exception e){
			System.out.println("Got Exception While Executing DispatchAddressValidation Method"+e);
		}
	
			

	}
	
	public void primaryContactValidation(WebDriver driver) {
		
		try{
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String c1="First Name:test";
		 String c2="First Name:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.primaryContactFirstName()).getAttribute("value");

		 String d1="Last Name:r5";
		 String d2="Last Name:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.primaryContactLastName()).getAttribute("value");

		 String e1="Primary Phone:(336) 456-7890";
		 String e2="Primary Phone:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.primaryContactPrimaryPhone()).getAttribute("value");

		 String f1="Email:no-email@dell.com";
		 String f2="Email:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.primaryContactEmailTextBox()).getAttribute("value");


		 String[] elementsHardCode={c1,d1,e1,f1};
		 String[] elementsDynamic={c2,d2,e2,f2};
		 int i;
		 for(i=0;i<elementsHardCode.length;i++){
			if(verification(elementsHardCode[i],elementsDynamic[i])==1)
			continue;
			else
			System.out.println("Values are not as expected");
			break;
		 }
		 if(i==3){
			System.out.println("All Values are as expected");
		 }
		}catch(Exception e){
			System.out.println("Got Exception While Executing PrimaryContactValidation Method"+e);
		}
	
			

	}
	
	public void alternateContactValidation(WebDriver driver) {

		try{
			
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String c1="First Name:DSA";
		 String c2="First Name:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactFirstName()).getAttribute("value");

		 String d1="Last Name:Peterson";
		 String d2="Last Name:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactLastNameTextBox()).getAttribute("value");

		 String e1="Primary Phone:(878) 787-8788";
		 String e2="Primary Phone:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactPrimaryPhone()).getAttribute("value");

		 String f1="Secondary Phone:(878) 787-9999";
		 String f2="Secondary Phone:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactSecondaryPhone()).getAttribute("value");

		 String f3="Email:test@dell.com";
		 String f4="Email:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.alternateContactEmail() ).getAttribute("value");

		 String[] elementsHardCode={c1,d1,e1,f1,f3};
		 String[] elementsDynamic={c2,d2,e2,f2,f4};
		 int i;
		 for(i=0;i<elementsHardCode.length;i++){
			if(verification(elementsHardCode[i],elementsDynamic[i])==1)
			continue;
			else
			System.out.println("Values are not as expected");
		 	break;
		 }
		 if(i==4){
			System.out.println("All Values are as expected");
		 }
		}catch(Exception e){
			System.out.println("Got Exception While Executing AlternateContactValidation Method"+e);
		}
	
			

	}
	
	public void serviceAttributeValidation(WebDriver driver) {
			
		try{
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String c1="Current Entitlement:Next Business Day-10x5";
		 String c2="Current Entitlement:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.currentEntitlementTextBox()).getAttribute("value");

		 String d1="Current Entitlement:Remote Effort-24x7";
		 String d2="Current Entitlement:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.locationCoverageTextBox()).getAttribute("value");

		 String e1="Premier Type:Complete Care";
		 String e2="Premier Type:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.premierTypeTextBox()).getAttribute("value");

		
		 String[] elementsHardCode={c1,d1,e1};
		 String[] elementsDynamic={c2,d2,e2};
		 int i;
		 for(i=0;i<elementsHardCode.length;i++){
			if(verification(elementsHardCode[i],elementsDynamic[i])==1)
			continue;
			else
			System.out.println("Values are not as expected");
			break;
		 }
		 if(i==2){
			System.out.println("All Values are as expected");
		 }
		}catch(Exception e){
			System.out.println("Got Exception While Executing ServiceAttributeValidation Method"+e);
		}
	
			

	}
	
	public void systemAttributeValidation(WebDriver driver) {
		try{	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String c1="System Classification:Desktop";
		String c2="System Classification:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.systemClassificationTextBox()).getAttribute("value");
		if(verification(c1,c2)==1)
			System.out.println("All Values are as expected");
		else
			
			System.out.println("Values are not as expected");
		
		}catch(Exception e){
			System.out.println("Got Exception While Executing SystemAttributeValidation Method"+e);
		}

	}

	public void serviceScheduleValidation(WebDriver driver) {
		
		try{	
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 String c1="Timezon:(GMT-06:00) Central Time (US & Canada)";
		 String c2="Timezon:"+driver.findElement(obj_ReviewAndSubmitDispatchPage.timezone()).getAttribute("value");
		 if(verification(c1,c2)==1)
			System.out.println("All Values are as expected");
		 else
			
			System.out.println("Values are not as expected");
		}catch(Exception e){
			System.out.println("Got Exception While Executing ServiceScheduleValidation Method"+e);
		}
		
	}

	public int verification(String s,String s2) {
	
		if(s.equals(s2))
		{
			System.out.println("Expected Value-"+s+" "+"Actual value-"+s2);
			return 1;
		}
		return 0;
		


	}



//----------------------------------------------after dispatch abhishek code---------------------------------	
	
	
	
	
	
	
	public void verifyDispatch(WebDriver driver)
	{
		
		System.out.println("Entering into verifyDispatch method");			

		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);
	
		try
		{
		System.out.println("Getting data from Region Text Box");	
		String actRegion = driver.findElement(obj_ReviewAddressAndDetailsPage.region()).getAttribute("value");
		
		System.out.println("Getting data from Country Text Box");
		String actCountry = driver.findElement(obj_ReviewAddressAndDetailsPage.country()).getAttribute("value");

		System.out.println("Getting data from TimeZone Text Box");
		String actTimeZone = driver.findElement(obj_ReviewAddressAndDetailsPage.timeZone()).getAttribute("value");

		System.out.println("Dispatch Region : "+actRegion);
		System.out.println("Dispatch Country : "+actCountry);
		System.out.println("Dispatch TimeZone : "+actTimeZone);
		
		System.out.println("Getting data from Status DropDown");
		String actStatus = driver.findElement(obj_ReviewAddressAndDetailsPage.status()).getAttribute("value");

		System.out.println("Getting data from SubStatus DropDown");
		String actSubStatus = driver.findElement(obj_ReviewAddressAndDetailsPage.subStatus()).getAttribute("value");
		
		System.out.println("Status Status : "+actStatus);
		System.out.println("Status Sub Status : "+actSubStatus);
		}
		catch(Exception e)
		{
			System.out.println("Caught exception while excuting verifyDispatch method: "+e);
		}
	}

	

	public void verifyAuditTrial(WebDriver driver)
	{
		
		System.out.println("Entering into verifyAuditTrial method");	

		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);
	
		
		try
		{
		System.out.println("Navigating to Audit Trail Tab ");
		driver.findElement(obj_ReviewAddressAndDetailsPage.auditTrail()).click();

		System.out.println("Getting Old value and New Value data from Table 1");
		String actOldvalueTable1 = driver.findElement(obj_ReviewAddressAndDetailsPage.oldvalueTable1()).getText();
		String actNewValueTable1 = driver.findElement(obj_ReviewAddressAndDetailsPage.newValueTable1()).getText();

		System.out.println("Getting Old value and New Value data from Table 2");
		String actOldvalueTable2 = driver.findElement(obj_ReviewAddressAndDetailsPage.oldvalueTable2()).getText();
		String actNewValueTable2 = driver.findElement(obj_ReviewAddressAndDetailsPage.newValueTable2()).getText();

		System.out.println("Getting Old value and New Value data from Table 3");
		String actOldvalueTable3 = driver.findElement(obj_ReviewAddressAndDetailsPage.oldvalueTable3()).getText();
		String actNewValueTable3 = driver.findElement(obj_ReviewAddressAndDetailsPage.newValueTable3()).getText();

		System.out.println("Getting Old value and New Value data from Table 4");
		String actOldvalueTable4 = driver.findElement(obj_ReviewAddressAndDetailsPage.oldvalueTable4()).getText();
		String actNewValueTable4 = driver.findElement(obj_ReviewAddressAndDetailsPage.newValueTable4()).getText();

		
		System.out.println("Following are the Audit Trail status");
		System.out.println("Old Value			New Value");
		System.out.println(actOldvalueTable1+"    "+actNewValueTable1);
		System.out.println(actOldvalueTable2+"    "+actNewValueTable2);
		System.out.println(actOldvalueTable3+"    "+actNewValueTable3);
		System.out.println(actOldvalueTable4+"    "+actNewValueTable4);

		}
		catch(Exception e)
		{
			System.out.println("Caught exception while excuting verifyAuditTrial method: "+e);
		}

	}


	public void verifyDeltaDispatch(WebDriver driver)
	{
		System.out.println("Entering into verifyDeltaDispatch method");				

		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);


		try
		{
			/*System.out.println("Navigating to Delta Dispatch Tab ");
			driver.findElement(obj_ReviewAddressAndDetailsPage.deltaDispatch()).click();

			System.out.println("Navigating to Comment SubTab ");
			driver.findElement(obj_ReviewAddressAndDetailsPage.comment()).click();

			System.out.println("Fatching the Data from Comments To Vendor");
			String actComments = driver.findElement(obj_ReviewAddressAndDetailsPage.commentsToVendor()).getText();
		
			System.out.println("Data in Comments To Vendor");
			System.out.println(actComments);
*/
		
			System.out.println("clicking on Servies Request Number link ");
			driver.findElement(obj_ReviewAddressAndDetailsPage.srLink()).click();
		
			System.out.println("Retrieving the Page Title");
			wait.until(ExpectedConditions.titleContains("Service Request Activities"));
			String actPageTitle = driver.getTitle();
		
			if(actPageTitle.contains("Service Request Activities"))
			{

				System.out.println("Currently Page is under Service Page and page title is :"+actPageTitle);
			}
			else 
			{
				System.out.println("not navigated to Service Page ");	
			}

		}
		catch(Exception e)
		{
			System.out.println("Caught exception while excuting verifyDeltaDispatch method: "+e);
		}
	




	}

	
	
	
	
	
	
	
	
	
	
		


	

	
	
	
	
	
	
	
	
	
	
	










}
	
	
	
	
	
	
	
	
	
	
	

