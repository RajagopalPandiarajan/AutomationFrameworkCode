package com.hashworks.delta_uat_automation.workflows;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hashworks.delta_uat_automation.pages.AssetsPage;
import com.hashworks.delta_uat_automation.pages.AssetsPageUX;
import com.hashworks.delta_uat_automation.pages.HomePage;
import com.hashworks.delta_uat_automation.pages.ReviewAddressAndDetailsPage;

public class AssetsWorkFlow {

	public AssetsWorkFlow () {
	}
	
	public boolean validate() {
		return false;
	}
	
	 
	public void ServiceTagSearchUX(WebDriver driver,String svcTag) throws Exception
	{
		AssetsPageUX AssetsPageobjUX = new AssetsPageUX();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 240);
		Thread.sleep(10000);
		driver.manage().timeouts().implicitlyWait(240, TimeUnit.SECONDS);
		//ResponsibilityWorkFlow ResponsibilityWorkFlowobj = new ResponsibilityWorkFlow();
		//Thread.sleep(10000);
		//ResponsibilityWorkFlowobj.ClosePopUp(driver);
		wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.acknowledgeButton()));
		//driver.findElement((By) HomePageobj.AcklodgementButton(driver)).click();
		driver.findElement(HomePageobj.acknowledgeButton()).click();
		System.out.println("Handled the pop up");
		System.out.println("Entering into Service Tag UX Search method");
		
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.ServiceTagSearchUX()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.ServiceTagSearchUX()));
			driver.findElement(AssetsPageobjUX.ServiceTagSearchUX()).sendKeys(svcTag);
			driver.findElement(AssetsPageobjUX.ServiceTagSearchUX()).sendKeys(Keys.ENTER);
			Thread.sleep(10000);//waiting for the service tag page to be loaded
			
			try 
			{	
				Thread.sleep(5000);
				wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.AddressLocationCheese()));
				wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.AddressLocationCheese()));
				driver.findElement(AssetsPageobjUX.AddressLocationCheese()).click();
				System.out.println("1");
				
                String txtValidateAddressLine1=driver.findElement(AssetsPageobjUX.txtValidateAddressLine1()).getAttribute("value");
                System.out.println("Address Location : First Line - "+txtValidateAddressLine1);
                
                String txtValidateState=driver.findElement(AssetsPageobjUX.txtValidateState()).getAttribute("value");
                System.out.println("Address Location : State -"+txtValidateState);
                
                String txtValidateCountry=driver.findElement(AssetsPageobjUX.txtValidateCountry()).getAttribute("value");
                System.out.println("Address Location : Country -"+txtValidateCountry);
                
                
                String txtValidatePostalCode=driver.findElement(AssetsPageobjUX.txtValidatePostalCode()).getAttribute("value");
                System.out.println("Address Location : Postal Code -"+txtValidatePostalCode);
                
                String txtValidateCity=driver.findElement(AssetsPageobjUX.txtValidateCity()).getAttribute("value");
                System.out.println("Address Location : City -"+txtValidateCity);
                
				wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.AddressLocationClose()));
				wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.AddressLocationClose()));
				System.out.println(AssetsPageobjUX.AddressLocationClose());
				driver.findElement(AssetsPageobjUX.AddressLocationClose()).click();
				System.out.println("Validation is done for the Address as part of service tag search");
				Thread.sleep(3000);
			}
			catch(Exception e)
			{
				System.out.println("Caught/Error on Validating the Address location");
				e.printStackTrace();
				System.exit(1);
			}
			
			try 
			{
				wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.AssetContactCheese()));
				wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.AssetContactCheese()));
				driver.findElement(AssetsPageobjUX.AssetContactCheese()).click();
				//wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.AssetContactAdd()));
				//wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.AssetContactAdd()));
				//driver.findElement(AssetsPageobjUX.AssetContactAdd()).click();
				System.out.println("2");
				
			    String txtValidatePrimaryFirstName=driver.findElement(AssetsPageobjUX.txtValidatePrimaryFirstName()).getAttribute("value");
                System.out.println("Asset Contacts : First Name - "+txtValidatePrimaryFirstName);
                driver.findElement(AssetsPageobjUX.txtValidatePrimaryFirstName()).sendKeys(Keys.TAB);

			    String txtValidatePrimaryLastName=driver.findElement(AssetsPageobjUX.txtValidatePrimaryLastName()).getAttribute("value");
                System.out.println("Asset Contacts : Last Name - "+txtValidatePrimaryLastName);
                driver.findElement(AssetsPageobjUX.txtValidatePrimaryLastName()).sendKeys(Keys.TAB);
                
			    String ValidateMiddleName=driver.findElement(AssetsPageobjUX.ValidateMiddleName()).getAttribute("value");
                System.out.println("Asset Contacts : Middle Name - "+ValidateMiddleName);
                driver.findElement(AssetsPageobjUX.ValidateMiddleName()).sendKeys(Keys.TAB);
                
                String ValidatePrimaryContact=driver.findElement(AssetsPageobjUX.ValidatePrimaryContact()).getText();
                System.out.println("Asset Contacts : Preferred Contact Method -"+ValidatePrimaryContact);
                driver.findElement(AssetsPageobjUX.ValidatePrimaryContact()).sendKeys(Keys.TAB);
                
                String CountryCodePrimary=driver.findElement(AssetsPageobjUX.CountryCodePrimary()).getText();
                System.out.println("Asset Contacts : Country Code -"+CountryCodePrimary);
                driver.findElement(AssetsPageobjUX.CountryCodePrimary()).sendKeys(Keys.TAB);
                
		/*	    String txtValidatePrimaryPhone=driver.findElement(AssetsPageobjUX.txtValidatePrimaryPhone()).getAttribute("value");
                System.out.println("Dispatch First Name is:"+txtValidatePrimaryPhone);
                
			    String txtValidatePrimaryEmail=driver.findElement(AssetsPageobjUX.txtValidatePrimaryEmail()).getAttribute("value");
                System.out.println("Dispatch First Name is:"+txtValidatePrimaryEmail); */
                
             
                
                
                wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.AssetContactCheese()));
                wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.AssetContactAdd()));
                driver.findElement(AssetsPageobjUX.AssetContactAdd()).click();
                
				/*wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@title='Primary Contact:Add']")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@title='Primary Contact:Add']")));
				driver.findElement(By.xpath("//button[@title='Primary Contact:Add']")).click();*/
				System.out.println("validated the address contacts details");
			}
			catch(Exception e)
			{
				System.out.println("Caught/Error on Validating the Asset location");
				e.printStackTrace();
				System.exit(1);
			}
			
			System.out.println("Service Tag Search is Completed");
			
			
			
		}
		catch(Exception e)
		{
			System.out.println("Caught/Error on Service Tag Search");
			e.printStackTrace();
			System.exit(1);
		}
		
	}

		
	public void SR_and_Activity_CreationUX(WebDriver driver, String Title, String DiagnosisTier1, String DiagnosisTier2, String DiagnosisTier3, String DiagnosisTier4)
	{
		
		AssetsPageUX AssetsPageobjUX = new AssetsPageUX();
		AssetsPage AssetsPageobj = new AssetsPage();
		WebDriverWait wait = new WebDriverWait(driver, 60);		
		System.out.println("Entered into the Service Request UX Creation Method...........");
		
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.CreateSR()));
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.CreateSR()));
			driver.findElement(AssetsPageobjUX.CreateSR()).click();
			Thread.sleep(3000);
			Alert al = driver.switchTo().alert();
			String message = al.getText();
			System.out.println("Test of the alrt"+message);
			al.accept();
			System.out.println("Clicked on the SR Creation Button");	
			
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.SRCreationText()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.SRCreationText()));
			driver.findElement(AssetsPageobjUX.SRCreationText()).clear();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.SRCreationText()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.SRCreationText()));
			driver.findElement(AssetsPageobjUX.SRCreationText()).sendKeys("Testing SR");
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.SRCreationText()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.SRCreationText()));
			driver.findElement(AssetsPageobjUX.SRCreationText()).sendKeys(Keys.TAB);
			System.out.println("SR Title is added");	
			
			
			// Valaidation of the SR which is created already
			
			 String txtValidateSRNumber=driver.findElement(AssetsPageobjUX.txtValidateSRNumber()).getText();
             System.out.println("SR Number is : "+txtValidateSRNumber);
             driver.findElement(AssetsPageobjUX.txtValidateSRNumber()).sendKeys(Keys.TAB);

        	 String txtValidateServiceTag=driver.findElement(AssetsPageobjUX.txtValidateServiceTag()).getAttribute("value");
             System.out.println("Service Tag is : "+txtValidateServiceTag);
             driver.findElement(AssetsPageobjUX.txtValidateServiceTag()).sendKeys(Keys.TAB);
             
             String txtValidateSRStatus=driver.findElement(AssetsPageobjUX.txtValidateSRStatus()).getAttribute("value");
             System.out.println("SR Status is :"+txtValidateSRStatus);
             driver.findElement(AssetsPageobjUX.txtValidateSRStatus()).sendKeys(Keys.TAB);
             
             String txtValidateOwner=driver.findElement(AssetsPageobjUX.txtValidateOwner()).getAttribute("value");
             System.out.println("Owner detail is : "+txtValidateOwner);
             driver.findElement(AssetsPageobjUX.txtValidateOwner()).sendKeys(Keys.TAB);
             
             
             String txtValidateGroup=driver.findElement(AssetsPageobjUX.txtValidateGroup()).getAttribute("value");
             System.out.println("Group detail is : "+txtValidateGroup);
             driver.findElement(AssetsPageobjUX.txtValidateGroup()).sendKeys(Keys.TAB);
							
			System.out.println("Trying to create the activity");
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisDropDown()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisDropDown()));
			driver.findElement(AssetsPageobjUX.DiagnosisDropDown()).click();
		
			//Entering the Environment Details
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.EnvironmentMain()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.EnvironmentMain()));
			driver.findElement(AssetsPageobjUX.EnvironmentMain()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.EnvironmentMain()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.EnvironmentMain()));
			driver.findElement(AssetsPageobjUX.EnvironmentMain()).sendKeys("None");
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.EnvironmentSub()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.EnvironmentSub()));
			driver.findElement(AssetsPageobjUX.EnvironmentSub()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.EnvironmentSub()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.EnvironmentSub()));
			driver.findElement(AssetsPageobjUX.EnvironmentSub()).sendKeys("None");
			System.out.println("Entered the Environment details");
	
			//Entering the Diagnosis details
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextOne()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextOne()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextOne()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextOne()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextOne()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextOne()).sendKeys("Bill To Customer");
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextTwo()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextTwo()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextTwo()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextTwo()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextTwo()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextTwo()).sendKeys("Contract or Service Issue");	
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextThree()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextThree()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextThree()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextThree()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextThree()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextThree()).sendKeys("Customer Warranty Expired");
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextFour()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextFour()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextFour()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.DiagnosisTextFour()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.DiagnosisTextFour()));
			driver.findElement(AssetsPageobjUX.DiagnosisTextFour()).sendKeys("Customer Accepting OOW Dispatch");
			System.out.println("Entered all the Disgnosis details");
			
			//Filling the activity details
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.ActivityType()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.ActivityType()));
			driver.findElement(AssetsPageobjUX.ActivityType()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.ActivityType()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.ActivityType()));
			driver.findElement(AssetsPageobjUX.ActivityType()).sendKeys("Call - Inbound");
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.ActivityDetails()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.ActivityDetails()));
			driver.findElement(AssetsPageobjUX.ActivityDetails()).clear();
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.ActivityDetails()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.ActivityDetails()));
			driver.findElement(AssetsPageobjUX.ActivityDetails()).sendKeys("Testing");
			System.out.println("Details of the activity is entered");
		
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.CreateActivity()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.CreateActivity()));
			driver.findElement(AssetsPageobjUX.CreateActivity()).click();
			System.out.println("Activity is Created");
			
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobjUX.CreateDispatch()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobjUX.CreateDispatch()));
			driver.findElement(AssetsPageobjUX.CreateDispatch()).click();
			System.out.println("Clicked on the Dispatch button");
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}

	 
	public void ServiceTagSearch(WebDriver driver,String svcTag) throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		ResponsibilityWorkFlow ResponsibilityWorkFlowobj = new ResponsibilityWorkFlow();
		//ResponsibilityWorkFlowobj.OpenDelta(driver);
		Thread.sleep(80000);
		AssetsPage AssetsPageobj = new AssetsPage();
		HomePage HomePageobj = new HomePage();
		WebDriverWait wait = new WebDriverWait(driver, 120);		
		try
		{
			
			System.out.println("Entered into ServiceTagSearch method........");
			//Clicking on the Assets Tab
			//Thread.sleep(40000);//80000
			//HomePageobj.lnkAssetsTab().wait(120000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.lnkAssetsTab(driver)));	
			wait.until(ExpectedConditions.presenceOfElementLocated(HomePageobj.acknowledgeButton()));
			driver.findElement(HomePageobj.acknowledgeButton()).click();
			HomePageobj.lnkAssetsTab(driver).click();
			Thread.sleep(5000);//10000
			//Waiting 60sec for the object servicetag textbox to be loaded
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.txtServiceTag()));
			WebElement serviceTagElement=driver.findElement(AssetsPageobj.txtServiceTag());
			if(serviceTagElement.isDisplayed())
			{
				System.out.println("ServiceTag textbox is displayed..........");
				driver.findElement(AssetsPageobj.txtServiceTag()).sendKeys(svcTag);
				driver.findElement(AssetsPageobj.txtServiceTag()).sendKeys(Keys.TAB);
				driver.findElement(AssetsPageobj.txtServiceTag()).sendKeys(Keys.ENTER);
				//driver.findElement(AssetsPageobj.btnGo()).click();
				Thread.sleep(5000);//20000
				wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.getCustomerNumber()));
				String getcustNum=driver.findElement(AssetsPageobj.getCustomerNumber()).getAttribute("value").trim();
				if(getcustNum==null || getcustNum=="")
				{
					System.err.println("Service Tag Search Failed : "+svcTag);

				}
				else
				{
					System.out.println("Service Tag Search Passed : "+svcTag);
				}
			}
			else
			{
				System.err.println("Service Tag Search box is not visible............");

			}		
			
			String getAssetHoldTxt=driver.findElement(AssetsPageobj.AssetHoldTxt()).getAttribute("value").trim();
			if (getAssetHoldTxt==null || getAssetHoldTxt=="")
			{
				System.out.println("Service Tag is on hold");
			}
			else
			{
				System.out.println("Service Tag is not on hold, validation pass "+getAssetHoldTxt);
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
		
	}

	public void SR_Creation(WebDriver driver, String Title, String DiagnosisTier1, String DiagnosisTier2, String DiagnosisTier3, String DiagnosisTier4)
	{
		
		AssetsPage AssetsPageobj = new AssetsPage();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 80);		
		System.out.println("Entered into the Service Request Creation Method...........");
		try
		{
			Thread.sleep(10000);
			driver.findElement(AssetsPageobj.btnNew_SRCreation()).click();
			Thread.sleep(5000);
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.txtSRTitle()));
			WebElement srtitle=driver.findElement(AssetsPageobj.txtSRTitle());
			if(srtitle.isDisplayed())
			{
				driver.findElement(AssetsPageobj.SRType()).clear();
				driver.findElement(AssetsPageobj.SRType()).sendKeys("Incident");
				driver.findElement(AssetsPageobj.SRType()).sendKeys(Keys.TAB);
				
				driver.findElement(AssetsPageobj.txtSRTitle()).sendKeys(Title);
				driver.findElement(AssetsPageobj.txtSRTitle()).sendKeys(Keys.TAB);
				
				driver.findElement(AssetsPageobj.txtDiagnosisTier1()).sendKeys(DiagnosisTier1);
				driver.findElement(AssetsPageobj.txtDiagnosisTier1()).sendKeys(Keys.TAB);
				driver.findElement(AssetsPageobj.txtDiagnosisTier2()).sendKeys(DiagnosisTier2);
				driver.findElement(AssetsPageobj.txtDiagnosisTier1()).sendKeys(Keys.TAB);
				driver.findElement(AssetsPageobj.txtDiagnosisTier3()).sendKeys(DiagnosisTier3);
				driver.findElement(AssetsPageobj.txtDiagnosisTier1()).sendKeys(Keys.TAB);
				driver.findElement(AssetsPageobj.txtDiagnosisTier4()).sendKeys(DiagnosisTier4);
				driver.findElement(AssetsPageobj.txtDiagnosisTier1()).sendKeys(Keys.TAB);
				SetContact(driver);
				String sr=driver.findElement(AssetsPageobj.lnkSRNumber()).getAttribute("text").trim();
				if(sr==null || sr=="" )
				{
					System.err.println("SR Creation Failed........");

				}
				System.out.println("The Newly Created SR Number is: "+sr);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public void SetContact(WebDriver driver)
	{
		AssetsPage AssetsPageobj = new AssetsPage();
		WebDriverWait wait = new WebDriverWait(driver, 60);		
		System.out.println("Entered into the SetContact Method...........");
		try
		{
			driver.findElement(AssetsPageobj.lnkLastNameIcon()).click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.btnLastNameMoveRight()));
			driver.findElement(AssetsPageobj.btnLastNameMoveRight()).click();
			Thread.sleep(3000);
			driver.findElement(AssetsPageobj.btnLastNameOK()).click();
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);

		}
	}
	
	public void ActivityCreation_Assets(WebDriver driver, String ActivityType, String ActivitySubType)
	{
		AssetsPage AssetsPageobj = new AssetsPage();
		ReviewAddressAndDetailsPage obj_ReviewAddressAndDetailsPage = new ReviewAddressAndDetailsPage();
		WebDriverWait wait = new WebDriverWait(driver, 60);		
		System.out.println("Entered into the ActivityCreation_Assets Method...........");
		try
		{
			driver.findElement(AssetsPageobj.btnNewButton_Activity()).click();
			/*driver.findElement(AssetsPageobj.btnNewButton_Activity()).sendKeys(Keys.TAB);
			driver.findElement(AssetsPageobj.btnNewButton_Activity()).sendKeys(Keys.TAB);*/
			Thread.sleep(6000);
			//wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.txtOwner()));
			driver.findElement(AssetsPageobj.txtOwner()).click();
			driver.findElement(AssetsPageobj.txtOwner()).sendKeys(Keys.TAB);
			Thread.sleep(2000);
			//String sr = driver.findElement(AssetsPageobj.txtSRnumber()).getAttribute("text");
			//System.out.println("The Newly Created SR Number is: "+sr);
			driver.findElement(AssetsPageobj.txtSRnumber()).sendKeys(Keys.TAB);
			Thread.sleep(2000);
			//entering Activity Type
			System.out.println("Entering Activity Type.....");
			//driver.findElement("Activity List Applet");
			
			//wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.ddlActivityType()));
			//driver.findElement(AssetsPageobj.ddlActivityType()).click();
			driver.findElement(AssetsPageobj.ddlActivityType()).sendKeys(ActivityType);
			driver.findElement(AssetsPageobj.ddlActivityType()).sendKeys(Keys.TAB);
			//System.out.println("Entering Activity Sub Type");
			
			//driver.findElement(AssetsPageobj.ddlActivitySubType()).sendKeys(Keys.TAB);
			//Thread.sleep(2000);
			/*System.out.println("Entering Agent Description");
			driver.findElement(AssetsPageobj.txtAgentDescription()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtAgentDescription()).sendKeys(Keys.TAB);
			System.out.println("Entering Symptoms");
			driver.findElement(AssetsPageobj.txtSymptoms()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtSymptoms()).sendKeys(Keys.TAB);	
			System.out.println("Entering Troubleshooting");
			driver.findElement(AssetsPageobj.txtTroubleshooting()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtTroubleshooting()).sendKeys(Keys.TAB);
			System.out.println("Entering Consulsion");
			driver.findElement(AssetsPageobj.txtConculsion()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtConculsion()).sendKeys(Keys.TAB);
			System.out.println("Entering Environment");
			driver.findElement(AssetsPageobj.ddlEnvironment()).sendKeys("Chrome OS");
			driver.findElement(AssetsPageobj.ddlEnvironment()).sendKeys(Keys.TAB);
			System.out.println("Entering Sub-Environment");
			driver.findElement(AssetsPageobj.ddlSubEnvironement()).sendKeys("None");
			Thread.sleep(2000);//4000
			*/
			Thread.sleep(3000);
			System.out.println("Clicking on the Open link of the activity.......");
			
		   /* JavascriptExecutor jse = (JavascriptExecutor) driver;
		    jse.executeScript("window.scrollBy(10,0)", "");
		    
		    Thread.sleep(3000);
			*/
			driver.findElement(AssetsPageobj.lnkStatus()).click();
			Thread.sleep(6000);
			
			if(ActivityType.contains("Credit") ||  ActivityType.contains("Exchange"))//Raj has changed this line of code
			{
				driver.findElement(AssetsPageobj.ddlActivitySubType()).sendKeys(ActivitySubType);
			}
			
			wait.until(ExpectedConditions.presenceOfElementLocated(AssetsPageobj.txtAgentDescription()));
			wait.until(ExpectedConditions.elementToBeClickable(AssetsPageobj.txtAgentDescription()));
			
			System.out.println("Entering Agent Description");
			driver.findElement(AssetsPageobj.txtAgentDescription()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtAgentDescription()).sendKeys(Keys.TAB);
			System.out.println("Entering Symptoms");
			driver.findElement(AssetsPageobj.txtSymptoms()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtSymptoms()).sendKeys(Keys.TAB);	
			System.out.println("Entering Troubleshooting");
			driver.findElement(AssetsPageobj.txtTroubleshooting()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtTroubleshooting()).sendKeys(Keys.TAB);
			System.out.println("Entering Consulsion");
			driver.findElement(AssetsPageobj.txtConculsion()).sendKeys("Test Data");
			driver.findElement(AssetsPageobj.txtConculsion()).sendKeys(Keys.TAB);
			System.out.println("Entering Environment");
			driver.findElement(AssetsPageobj.ddlEnvironment()).clear();//Raj added this line
			driver.findElement(AssetsPageobj.ddlEnvironment()).sendKeys("Chrome OS");
			driver.findElement(AssetsPageobj.ddlEnvironment()).sendKeys(Keys.TAB);
			System.out.println("Entering Sub-Environment");
			driver.findElement(AssetsPageobj.ddlSubEnvironement()).clear();//Raj added this line
			driver.findElement(AssetsPageobj.ddlSubEnvironement()).sendKeys("None");
			driver.findElement(AssetsPageobj.ddlSubEnvironement()).sendKeys(Keys.TAB);
			Thread.sleep(2000);
			
			
			
			
			wait.until(ExpectedConditions.presenceOfElementLocated(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
			//wait.until(ExpectedConditions.invisibilityOfElementLocated("))
			
			wait.until(ExpectedConditions.elementToBeClickable(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton()));
			WebElement btncreateDispatch=driver.findElement(obj_ReviewAddressAndDetailsPage.getCreateDispatchButton());
			
			
			
			    int attempts = 0;
		        while(attempts < 4) {
		            try {
		            	btncreateDispatch.isDisplayed();
		               // result = true;
		                break;
		            } catch(Exception e) {
		            	Thread.sleep(2000);
		            }
		            
		            attempts++;
		        }
			
			if(btncreateDispatch.isDisplayed())
			{
				System.out.println("Activity Created Successfully...........");
			}
			else
			{
				System.err.println("Activity Creation FAILED..........");

			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.exit(1);

		}
		
	}
	
	
}
