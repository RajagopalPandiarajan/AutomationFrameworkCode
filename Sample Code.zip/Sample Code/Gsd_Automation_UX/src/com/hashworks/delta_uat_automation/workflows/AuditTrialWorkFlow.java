package com.hashworks.delta_uat_automation.workflows;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hashworks.delta_uat_automation.pages.AuditTrialPage;

public class AuditTrialWorkFlow {
	
	public void AuditTrial_Validation(WebDriver driver) throws Exception
	{
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		AuditTrialPage AuditTrialPageobj = new AuditTrialPage();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,150);
		
		
		try{
			
			System.out.println("Entered into AuditTrial Validation..........");
			//System.out.println(AuditTrialPageobj.btnAuditTrialButton());
			//System.out.println("HI");
			
			wait.until(ExpectedConditions.elementToBeClickable(AuditTrialPageobj.btnDispatchDetails())).click();
			
			System.out.println("waiting to click on the Audit Trail");
			//Thread.sleep(20000);
			System.out.println(AuditTrialPageobj.btnAuditTrialButton());
			wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.btnAuditTrialButton()));
			//wait.until(ExpectedConditions.elementToBeClickable(AuditTrialPageobj.btnAuditTrialButton()));
			//Thread.sleep(10000);
			driver.findElement(AuditTrialPageobj.btnAuditTrialButton()).click();
			System.out.println("It clicked");
			//Thread.sleep(10000);
			//driver.findElement(AuditTrialPageobj.btnAuditTrialButton()).click();
			//System.out.println("2");

			//driver.findElement(AuditTrialPageobj.btnAuditTrialButton()).click();
			//System.out.println("Hello");
/*			String DisPhoneValue=driver.findElement(obj_ReviewAndSubmitDispatchPageUX.txtValidateDisPhone()).getAttribute("value");
			System.out.println("Dispatch Phone Number is:"+DisPhoneValue);*/
			
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getEmployeeLogin()));
		    String Employee=driver.findElement(AuditTrialPageobj.getValidateEmployee()).getAttribute("title");
		    System.out.println("EmployeeLogin Checked Successfully, The Employee Login Number is: "+Employee);
			
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getOperation()));
		    String Field=driver.findElement(AuditTrialPageobj.getValidateField()).getAttribute("title");
		    //String Operation=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    System.out.println("Field Checked Successfully, The Operation Value is: "+Field);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getField()));
		    //String Field=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String Operation=driver.findElement(AuditTrialPageobj.getValidateOperation()).getAttribute("title");
		    System.out.println("Operation Checked Successfully, The Operation value is: "+Operation);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getOldValue()));
		    //String OldValue=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String OldValue=driver.findElement(AuditTrialPageobj.getValidateOldValue()).getAttribute("title");
		    System.out.println("OldValue Checked Successfully, The OldValue Number is: "+OldValue);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getNewValue()));
		   // String NewValue=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String NewValue=driver.findElement(AuditTrialPageobj.getValidateNewValue()).getAttribute("title");
		    System.out.println("NewValue Checked Successfully, The NewValue Number is: "+NewValue);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getDate()));
		    //String Date=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String Date=driver.findElement(AuditTrialPageobj.getValidateDate()).getAttribute("title");
		    System.out.println("Date Checked Successfully, The Date is: "+Date);
		    
		    wait.until(ExpectedConditions.elementToBeClickable(AuditTrialPageobj.btnDispatchAttributes())).click();
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getCreated1()));
		    //String Created1=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String DSP=driver.findElement(AuditTrialPageobj.getValidateDSP()).getAttribute("value");
		    System.out.println("DSP Checked Successfully, The DSP Number is: "+DSP);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getReceiver1()));
		    //String Receiver1=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String DPSType=driver.findElement(AuditTrialPageobj.getValidateDPSType()).getAttribute("value");
		    System.out.println("DPSType Checked Successfully, The DPS Type Number is: "+DPSType);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getType1()));
		    //String Type1=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CallType=driver.findElement(AuditTrialPageobj.getValidateCallType()).getAttribute("value");
		    System.out.println("CallType Checked Successfully, The Call Type Number is: "+CallType);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getInstructions1()));
		    //String Instructions1=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String TimeZone=driver.findElement(AuditTrialPageobj.getValidateTimeZone()).getAttribute("value");
		    System.out.println("TimeZone Checked Successfully, The TimeZone is: "+TimeZone);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.btnInstructionButton())).click();
		    
		   // wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.btnInstructionButton())).click();
		    
		    wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.btnCommentsToVendor())).click();
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getCreatedBy1()));
		    //String CreatedBy1=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CommentsCreated=driver.findElement(AuditTrialPageobj.getCommentsCreated()).getText();
		    System.out.println("CommentsCreated Checked Successfully, The CommentsCreated value is: "+CommentsCreated);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getCreated2()));
		    //String Created2=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CommentsName=driver.findElement(AuditTrialPageobj.getCommentsName()).getText();
		    System.out.println("CommentsName Checked Successfully, The Comments Name is: "+CommentsName);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getReceiver2()));
		    //String Receiver2=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CommentsReceiver=driver.findElement(AuditTrialPageobj.getCommentsReceiver()).getText();
		    System.out.println("CommentsReceiver Checked Successfully, The Comments Receiver value is: "+CommentsReceiver);
		    
		    //wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getType2()));
		    //String Type2=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CommentsType=driver.findElement(AuditTrialPageobj.getCommentsType()).getText();
		    System.out.println("CommentsType Checked Successfully, The CommentsType value is: "+CommentsType);
		    
		   // wait.until(ExpectedConditions.presenceOfElementLocated(AuditTrialPageobj.getInstructions2()));
		    //String Instructions2=driver.findElement(AuditTrialPageobj.getEmployeeLogin()).getAttribute("value");
		    String CommentsInstruction=driver.findElement(AuditTrialPageobj.getCommentsInstruction()).getText();
		    System.out.println("CommentsInstruction Checked Successfully, The CommentsInstruction value is: "+CommentsInstruction);

		    
		    /*String auditEmployeeLogin=AuditTrialPageobj.fetchEmployeeLogin(driver).getAttribute("value").trim();
		    String auditOperation=AuditTrialPageobj.fetchOperation(driver).getAttribute("value").trim();
		    String auditField=AuditTrialPageobj.fetchField(driver).getAttribute("value").trim();
		    String auditOldValue=AuditTrialPageobj.fetchOldValue(driver).getAttribute("value").trim();
		    String auditNewValue=AuditTrialPageobj.fetchNewValue(driver).getAttribute("value").trim();
		    String auditDate=AuditTrialPageobj.fetchDate(driver).getAttribute("value").trim();
		    String instructionCreated1=AuditTrialPageobj.fetchCreated1(driver).getAttribute("value").trim();
		    String instructionReceiver1=AuditTrialPageobj.fetchReceiver1(driver).getAttribute("value").trim();
		    String instructionType1=AuditTrialPageobj.fetchType1(driver).getAttribute("value").trim();
		    String instructionInstructions1=AuditTrialPageobj.fetchInstructions1(driver).getAttribute("value").trim();
		    String instructionCreatedBy1=AuditTrialPageobj.fetchCreatedBy1(driver).getAttribute("value").trim();
		    String instructionCreated2=AuditTrialPageobj.fetchCreated2(driver).getAttribute("value").trim();
		    String instructionReceiver2=AuditTrialPageobj.fetchReceiver2(driver).getAttribute("value").trim();
		    String instructionType2=AuditTrialPageobj.fetchType2(driver).getAttribute("value").trim();
		    String instructionInstructions2=AuditTrialPageobj.fetchInstructions2(driver).getAttribute("value").trim();
		    String instructionCreatedBy2=AuditTrialPageobj.fetchCreatedBy2(driver).getAttribute("value").trim();
		    
		    System.out.println("EmployeeLogin Checked Successfully, The Employee Login Number is: "+auditEmployeeLogin);
		    System.out.println("Operation Checked Successfully, The Operation value is: "+auditOperation);
		    System.out.println("Field Checked Successfully, The Field value is: "+auditField);
		    System.out.println("OldValue Checked Successfully, The OldValue is: "+auditOldValue);
		    System.out.println("NewValue Checked Successfully, The NewValue is: "+auditNewValue);
		    System.out.println("Date Successfully, The Date is: "+auditDate);
		    System.out.println("Created1 Checked Successfully, The Created1 value is: "+instructionCreated1);
		    System.out.println("Receiver1 checked Successfully, The Receiver1 value is: "+instructionReceiver1);
		    System.out.println("Type1 Checked Successfully, The Type1 value is: "+instructionType1);
		    System.out.println("Instructions1 Checked Successfully, The Instructions1 value is: "+instructionInstructions1);
		    System.out.println("CreatedBy Checked Successfully, The CreatedBy value is: "+instructionCreatedBy1);
		    System.out.println("Created2 Checked Successfully, The Created2 value is: "+instructionCreated2);
		    System.out.println("Receiver2 Checked Successfully, The Receiver2 value is: "+instructionReceiver2);
		    System.out.println("Type2 Checked Successfully, The Type2 value is: "+instructionType2);
		    System.out.println("Instructions2 Checked Successfully, The Instructions2 value is: "+instructionInstructions2);
		    System.out.println("CreatedBy2 Checked Successfully, The CreatedBy2 value is: "+instructionCreatedBy2);*/
		    
		}
		catch(Exception e){
			System.out.println("Caught Exception "+e);
		}
}
}
