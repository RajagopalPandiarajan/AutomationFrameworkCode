package com.hashworks.delta_uat_automation.testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.hashworks.delta_uat_automation.pages.Pojo;
import com.hashworks.delta_uat_automation.utility.BrowserInitialization;
import com.hashworks.delta_uat_automation.workflows.AssetsWorkFlow;
import com.hashworks.delta_uat_automation.workflows.AuditTrialWorkFlow;
import com.hashworks.delta_uat_automation.workflows.CreateDispachWorkFlow;
import com.hashworks.delta_uat_automation.workflows.CreateDispatchNegWorkFlow;
import com.hashworks.delta_uat_automation.workflows.ResponsibilityWorkFlow;

public class CRE_UX_FSD_Test_Cases extends BrowserInitialization {
	
	Pojo obj_LoginPage_Pojo=null;
	
	@BeforeSuite
	public void  loadObjectsPropertiesFromExcel()
	{		
		obj_LoginPage_Pojo=new Pojo();
		obj_LoginPage_Pojo.storePageDataFromExcel();	
	}
	
	@Test
	public void Hashworks () 
	{
		try
		{
			//Workflow Objects
			ResponsibilityWorkFlow ResponsibilityWorkFlowobj = new ResponsibilityWorkFlow();
			AssetsWorkFlow AssetsWorkFlowobj = new AssetsWorkFlow();
			CreateDispachWorkFlow CreateDispachWorkFlowobj = new CreateDispachWorkFlow();
			CreateDispatchNegWorkFlow CreateDispatchNegWorkFlowobj = new CreateDispatchNegWorkFlow();
			AuditTrialWorkFlow AuditTrialWorkFlowobj = new AuditTrialWorkFlow();

			System.out.println("Framework is working : Cool ");
			
					//FSD TEST CASES
/*			// Adding aall the necessary Responsibilities
			ResponsibilityWorkFlowobj.AddResponsibilitiesFSD(driver, "User ID", "Rajagopal_P", "ISP Base", "ISP Super Administrator","ISP FSD Manager","ISP FSD L2");
			setBrowser();
			AssetsWorkFlowobj.ServiceTagSearch(driver, "7ZKQQ3J");
			AssetsWorkFlowobj.SR_Creation(driver, "SR Title",  "Bill To Customer", "Processing", "Order Placed Wrong", "Order Placed Wrong");
			AssetsWorkFlowobj.ActivityCreation_Assets(driver, "Break Fix", "");
			CreateDispachWorkFlowobj.DispatchCreation_BreakFix(driver,"Parts Only","00001");*/
			
		/*	//FSD Second TEST CASE
			// Adding aall the necessary Responsibilities
			ResponsibilityWorkFlowobj.AddResponsibilitiesFSD(driver, "User ID", "Rajagopal_P", "ISP Base", "ISP Super Administrator","ISP FSD Manager","ISP FSD L2");
			setBrowser();
			AssetsWorkFlowobj.ServiceTagSearch(driver, "DSUS617");//DSUS617,7ZKQQ3J
			AssetsWorkFlowobj.SR_Creation(driver, "SR Title",  "Bill To Customer", "Processing", "Order Placed Wrong", "Order Placed Wrong");
			AssetsWorkFlowobj.ActivityCreation_Assets(driver, "Break Fix", "");
			CreateDispachWorkFlowobj.DispatchCreation_PartsAndLabour(driver,"Parts and Labor","00001");*/
	
	/*		
		//	CRE TEST CASES
			//Adding the necessary Responsibilities
			ResponsibilityWorkFlowobj.AddResponsibilitiesCRE(driver, "User ID", "Rajagopal_P", "ISP Base", "ISP Super Administrator");
			setBrowser();
			// Service Tag Search in CRE
			AssetsWorkFlowobj.ServiceTagSearch(driver, "DSUS614");//JPOD020
			//SR# Creation in Open UI
			AssetsWorkFlowobj.SR_Creation(driver, "SR Title", "Bill To Customer", "Contract or Service Issue", "Customer Warranty Expired", "Customer Accepting OOW Dispatch");
			//Activity Creation in Open UI
			AssetsWorkFlowobj.ActivityCreation_Assets(driver, "Exchange", "New System");
			// Calling the CRE Create Dispatch Negative Scenario
			CreateDispatchNegWorkFlowobj.CreateDispatchNeg(driver);*/
		

			
			
			//UX TEST CASES - Collect and Return
			//Adding the necessary Responsibilities
			//ResponsibilityWorkFlowobj.AddResponsibilitiesUX(driver, "User ID", "Rajagopal_P", "ISP Base", "ISP Super Administrator","ISP Tech Support UX");
			//setBrowser();
			//Service Tag Search in UX  Screen
			/*AssetsWorkFlowobj.ServiceTagSearchUX(driver, "8W0YXW1");//JPOD020//JCP9J1X
			//SR and Activity Creation in UX Screen
			AssetsWorkFlowobj.SR_and_Activity_CreationUX(driver, "SR Title", "Bill To Customer", "Contract or Service Issue", "Customer Warranty Expired", "Customer Accepting OOW Dispatch");
			//Dispatch Creation in UX Screen
			//CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX(driver, "Incorrect Diagnostics", "Collect and Return", "001 - Collection with Box", "Ongoing supporting issue", "21TUG");
			CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX2(driver, "Incorrect Diagnostics", "Parts and Labor", "PWS-Parts and Labor", "21TUG");
			
			AuditTrialWorkFlowobj.AuditTrial_Validation(driver);
			//CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX(driver, "Parts and Labour", "21TUG");		
*/			
			
			/*
			//UX TEST CASES - Parts and Labor
			//Adding the necessary Responsibilities
			//ResponsibilityWorkFlowobj.AddResponsibilitiesUX(driver, "User ID", "Rajagopal_P", "ISP Base", "ISP Super Administrator","ISP Tech Support UX");
			//setBrowser();
			//Service Tag Search in UX  Screen
			AssetsWorkFlowobj.ServiceTagSearchUX(driver, "8W0YXW1");// --  --8W0YXW1//JCP9J1X
			//SR and Activity Creation in UX Screen
			AssetsWorkFlowobj.SR_and_Activity_CreationUX(driver, "SR Title", "Bill To Customer", "Contract or Service Issue", "Customer Warranty Expired", "Customer Accepting OOW Dispatch");
			//Dispatch Creation in UX Screen
			//CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX(driver, "Incorrect Diagnostics", "Collect and Return", "001 - Collection with Box", "Ongoing supporting issue", "21TUG");
			CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX2(driver, "Incorrect Diagnostics", "Parts and Labor", "PWS-Parts and Labor", "21TUG");
			AuditTrialWorkFlowobj.AuditTrial_Validation(driver);
			//CreateDispachWorkFlowobj.Dispatch_OOW_B2DUX(driver, "Parts and Labour", "21TUG");		
*/		
			
			

		
			
			
			
			
	}
		catch(Exception e)
		{
			System.err.println(e);
		}
	}

}

//TS_EXG_Region_US