package com.hashworks.delta_uat_automation.pages;


import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class AssetsPageUX extends Pojo {

	public AssetsPageUX () {
	}
	
	public boolean validate() {
		return false;
	}
	
	
	public By ServiceTagSearchUX() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("ServiceTagSearchUX"));
	}
	
	public By AddressLocationCheese() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("AddressLocationCheese"));
	}
	
	public By AddressLocationClose() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("AddressLocationClose"));
	}
	
	public By AssetContactCheese() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("AssetContactCheese"));
	}
	
	public By AssetContactAdd() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("AssetContactAdd"));
	}
	
	public By CreateSR() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("CreateSR"));
	}
	
	public By SRCreationText() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("SRCreationText"));
	}
	
	public By DiagnosisDropDown() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("DiagnosisDropDown"));
	}
	
	public By DiagnosisTextOne() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("DiagnosisTextOne"));
	}
	
	public By DiagnosisTextTwo() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("DiagnosisTextTwo"));
	}
	
	public By DiagnosisTextThree() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("DiagnosisTextThree"));
	}
	
	public By DiagnosisTextFour() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("DiagnosisTextFour"));
	}
	
	public By EnvironmentMain() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("EnvironmentMain"));
	}
	
	public By EnvironmentSub() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("EnvironmentSub"));
	}
	
	public By ActivityType() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("ActivityType"));
	}
	
	public By ActivityDetails() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("ActivityDetails"));
	}
	
	public By CreateActivity() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("CreateActivity"));
	}
	
	public By CreateDispatch() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPageUX_Data.get("CreateDispatch"));
	}
	
	// Validation Page Classes

	public By txtValidateAddressLine1() throws Exception{
        
        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateAddressLine1"));
 
	 }
	
	
	public By txtValidateState() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateState"));
	 
	 }
	
	public By txtValidateCountry() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateCountry"));
	 
	 }
	
	public By txtValidatePostalCode() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePostalCode"));
	 
	 }
	
	public By txtValidateCity() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateCity"));
	 
	 }
	
	public By txtValidatePrimaryFirstName() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePrimaryFirstName"));
	 
	 }
	
	public By txtValidatePrimaryLastName() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePrimaryLastName"));
	 
	 }
	
	public By txtValidatePrimaryPhone() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePrimaryPhone"));
	 
	 }
	
	public By txtValidatePrimaryEmail() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePrimaryEmail"));
	 
	 }
	
	public By txtValidateSRNumber() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateSRNumber"));
	 
	 }
	
	public By txtValidateServiceTag() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateServiceTag"));
	 
	 }
	
	public By txtValidateSRStatus() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateSRStatus"));
	 
	 }
	
	public By txtValidateOwner() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateOwner"));
	 
	 }
	
	public By txtValidateGroup() throws Exception{
	        
	        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateGroup"));
	 
	 }
	
	public By CountryCodePrimary() throws Exception{
        
        return CommonUtility.getLocator(AssetsPageUX_Data.get("CountryCodePrimary"));
  }
	
	public By ValidateMiddleName() throws Exception{
        
        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidateMiddleName"));
 
 }
	
	public By ValidatePrimaryContact() throws Exception{
        
        return CommonUtility.getLocator(AssetsPageUX_Data.get("ValidatePrimaryContact"));
  
 }
	
}
