package com.hashworks.delta_uat_automation.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class HomePage extends Pojo {

	public HomePage () {
	}
	
	public boolean validate() {
		return false;
	}
	
	
	public WebElement lnkAssetsTab(WebDriver driver)
	{
		try
		{
		 //return CommonUtility.getLocator(HomePage_Obj.get("AssetsTab"));
		 return driver.findElement(By.linkText("Assets"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
		
	}
	public WebElement popupCloseButton(WebDriver driver)
    {
           return driver.findElement(By.name("SBLCloseBtn"));
    }

/*	public WebElement AcklodgementButton(WebDriver driver)
    {
           return driver.findElement(By.xpath("//span[text()='Acknowledge']"));
    }
*/
	
	public By acknowledgeButton() throws Exception{
		return CommonUtility.getLocator(HomePage_Data.get("AcknowledgeButton"));
	}
	public By LogOutButton1() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("LogOutButton"));
	}
	
	public WebElement LogOutButton(WebDriver driver)
	{
		
		return driver.findElement(By.xpath("//*[@id='tb_17']/span/img"));
	}


}
