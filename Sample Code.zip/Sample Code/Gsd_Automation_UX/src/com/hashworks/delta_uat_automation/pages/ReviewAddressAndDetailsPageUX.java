package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;



public class ReviewAddressAndDetailsPageUX extends Pojo{
	
	
	//-----------------------------UX objects-----------------------------------------------------------------------------------
    
    

    public By addressValidationNextButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("AddressValidationNextButton"));
	 
	}
    
    

    public By noAlternateContactCheckBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("NoAlternateContactCheckBox"));
	 
	}
    


    public By newtDispatchNextButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("NewtDispatchNextButton"));
	 
	}
    

    public By repeatReasonTextbox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("RepeatReasonTextbox"));
	 
	}
    
    

    public By dispatchCategory() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("DispatchCategory"));
	 
	}
    
    

    public By confirmContactNextButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPageUX_Data.get("ConfirmContactNextButton"));
	 
	}


}
