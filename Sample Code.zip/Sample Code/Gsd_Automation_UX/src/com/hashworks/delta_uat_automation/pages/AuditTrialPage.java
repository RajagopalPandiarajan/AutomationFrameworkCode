package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class AuditTrialPage extends Pojo {

	public AuditTrialPage () {
	}
	
	public boolean validate() {
		return false;
	}
	
	public By btnDispatchDetails() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("DispatchDetails"));
	}
	
	public By btnDispatchAttributes() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("DispatchAttributes"));
	}
	

	public By btnAuditTrialButton() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("AuditTrial"));
	}
	
	public By getValidateEmployee() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateEmployee"));
	}

	public By getValidateField() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateField"));
	}
	
	public By getValidateOperation() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateOperation"));
	}
	
	public By getValidateOldValue() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateOldValue"));
	}
	
	public By getValidateNewValue() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateNewValue"));
	}
	
	public By getValidateDate() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateDate"));
	}
	
	public By getValidateDSP() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateDSP"));
	}
	
	public By getValidateDPSType() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateDPSType"));
	}
	
/*	public By btnDispatchAttributes() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("DispatchAttributes"));
	}*/
	
	public By getValidateCallType() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateCallType"));
	}
	
	public By getValidateTimeZone() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ValidateTimeZone"));
	}
	
	public By btnProviderComments() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("ProviderComments"));
	}
	
	public By btnCommentsToVendor() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsToVendor"));
	}
	
	public By getCommentsCreated() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsCreated"));
	}
	
	public By getCommentsName() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsName"));
	}
	
	public By getCommentsReceiver() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsReceiver"));
	}
	
	public By getCommentsType() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsType"));
	}
	
	public By getCommentsInstruction() throws Exception
	{
		
		 return CommonUtility.getLocator(AuditTrialPageUX_Data.get("CommentsInstruction"));
	}
	

	
	/*public WebElement fetchEmployeeLogin(WebDriver driver)
	{
		return driver.findElement(By.id("3_Employee_Login"));
	}
	
	public WebElement fetchOperation(WebDriver driver)
	{
		return driver.findElement(By.id("3_Operation"));
	}
	
	public WebElement fetchField(WebDriver driver)
	{
		return driver.findElement(By.id("3_Field"));
	}
	
	public WebElement fetchOldValue(WebDriver driver)
	{
		return driver.findElement(By.id("3_Old_Value"));
	}
	
	public WebElement fetchNewValue(WebDriver driver)
	{
		return driver.findElement(By.id("3_New_Value"));
	}
	
	public WebElement fetchDate(WebDriver driver)
	{
		return driver.findElement(By.id("3_Date"));
	}
	
	public WebElement fetchCreated1(WebDriver driver)
	{
		return driver.findElement(By.id("1_Created"));
	}
	
	public WebElement fetchReceiver1(WebDriver driver)
	{
		return driver.findElement(By.id("1_s_16_l_Instruction_Type"));
	}
	
	public WebElement fetchType1(WebDriver driver)
	{
		return driver.findElement(By.id("1_s_16_l_ISP_Instruction_Area"));
	}
	
	public WebElement fetchInstructions1(WebDriver driver)
	{
		return driver.findElement(By.id("1_Instruction"));
	}
	
	public WebElement fetchCreatedBy1(WebDriver driver)
	{
		return driver.findElement(By.id("1_ISP_Created_By"));
	}
	
	public WebElement fetchCreated2(WebDriver driver)
	{
		return driver.findElement(By.id("2_Created"));
	}
	
	public WebElement fetchReceiver2(WebDriver driver)
	{
		return driver.findElement(By.id("2_s_16_l_Instruction_Type"));
	}
	
	public WebElement fetchType2(WebDriver driver)
	{
		return driver.findElement(By.id("2_s_16_l_ISP_Instruction_Area"));
	}
	
	public WebElement fetchInstructions2(WebDriver driver)
	{
		return driver.findElement(By.id("2_Instruction"));
	}
	
	public WebElement fetchCreatedBy2(WebDriver driver)
	{
		return driver.findElement(By.id("2_ISP_Created_By"));
	}*/
		
}
