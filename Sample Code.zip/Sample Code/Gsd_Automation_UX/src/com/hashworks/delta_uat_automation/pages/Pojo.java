package com.hashworks.delta_uat_automation.pages;

import java.util.Hashtable;

import com.hashworks.delta_uat_automation.utility.ReadExcel;

//This class will handle retrieving data from excel and storing it in objects
public class Pojo {

	public static Hashtable<String,String> ReviewAddressAndDetailsPage_Data=null;
	public static Hashtable<String,String> ReviewAndSubmitDispatchPage_Data=null;
	public static Hashtable<String,String> ReviewAndSelectPartsPage_Data=null;
	public static Hashtable<String,String> HomePage_Data=null;
	public static Hashtable<String,String> AssetsPage_Data=null;
	public static Hashtable<String,String> ResponsibilityPage_Data=null;
	
	//UX Page Variables
	public static Hashtable<String,String> AssetsPageUX_Data=null;
	public static Hashtable<String,String> ReviewAddressAndDetailsPageUX_Data=null;
	public static Hashtable<String,String> ReviewAndSubmitDispatchPageUX_Data=null;
	public static Hashtable<String,String> AuditTrialPageUX_Data=null;


	
	
	//read from excel store it in hash objects for all pages
	public void storePageDataFromExcel(){
		
		/*ReviewAddressAndDetailsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "ReviewAddressAndDetailsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAndSelectPartsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "ReviewAndSelectPartsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		HomePage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "HomePage", "Object Name / Label Name", "Locator Type%Object Properties");

		AssetsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "AssetsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ResponsibilityPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "ResponsibilityPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		AssetsPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "AssetsPageUX", "Object Name / Label Name", "Locator Type%Object Properties");

		//UX Pages
		
		ReviewAddressAndDetailsPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "ReviewAddressandDetailsPageUX", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAndSubmitDispatchPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/ObjectRepository.xlsx", "ReviewAndSubmitDispatchUX", "Object Name / Label Name", "Locator Type%Object Properties");
						
		*/
		
		ReviewAddressAndDetailsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ReviewAddressAndDetailsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAndSubmitDispatchPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ReviewAndSubmitDispatch", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAndSelectPartsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ReviewAndSelectPartsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		HomePage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "HomePage", "Object Name / Label Name", "Locator Type%Object Properties");

		AssetsPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "AssetsPage", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ResponsibilityPage_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ResponsibilityPage", "Object Name / Label Name", "Locator Type%Object Properties");
		

		//UX Pages
		
		AssetsPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "AssetsPageUX", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAddressAndDetailsPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ReviewAddressandDetailsPageUX", "Object Name / Label Name", "Locator Type%Object Properties");
		
		ReviewAndSubmitDispatchPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "ReviewAndSubmitDispatchUX", "Object Name / Label Name", "Locator Type%Object Properties");
						
		AuditTrialPageUX_Data=ReadExcel.getEntireExcelSheetData("./Object_Data_Repository/SIT6ObjectRepository.xlsx", "AuditTrialPageUX", "Object Name / Label Name", "Locator Type%Object Properties");

		
	}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
}
