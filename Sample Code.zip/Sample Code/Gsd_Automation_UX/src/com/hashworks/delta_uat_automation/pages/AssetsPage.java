package com.hashworks.delta_uat_automation.pages;


import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class AssetsPage extends Pojo {

	public AssetsPage () {
	}
	
	public boolean validate() {
		return false;
	}
	
	
	
	public By SRType() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("SRType"));
	}
	
	
	public By txtServiceTag() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("ServiceTag"));
	}
	public By btnGo() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Go"));
	}

	public By getCustomerNumber() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("CustomerNumber"));
	}
	
	public By getOrderNumber() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("OrderNumber"));
	}
	
	public By btnNew_SRCreation() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("NewButtonSR"));
	}
	
	public By lnkSRNumber() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("SRNumber"));
	}
	
	public By txtSRTitle() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("SRTitle"));
	}
	public By txtDiagnosisTier1() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("DiagnosisTier1"));
	}
	
	public By txtDiagnosisTier2() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("DiagnosisTier2"));
	}
	
	public By txtDiagnosisTier3() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("DiagnosisTier3"));
	}
	
	public By txtDiagnosisTier4() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("DiagnosisTier4"));
	}
	public By lnkLastNameIcon() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("LastNameIcon"));
	}
	public By btnLastNameMoveRight() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("LastNameMoveRight"));
	}
	public By btnLastNameOK() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("LastNameOK"));
	}
	public By btnNewButton_Activity() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("NewButtonActivity"));
	}
	public By txtOwner() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Owner"));
	}
	public By txtSRnumber() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("SRnumber"));
	}
	public By ddlActivityType() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("ActivityType"));
	}
	public By ddlActivitySubType() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("ActivitySubType"));
	}
	public By txtAgentDescription() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("AgentDescription"));
	}
	public By txtSymptoms() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Symptoms"));
	}
	public By txtTroubleshooting() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Troubleshooting"));
	}
	public By txtConculsion() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Conculsion"));
	}
	public By ddlEnvironment() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Environment"));
	}
	public By ddlSubEnvironement() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("SubEnvironement"));
	}
	public By lnkStatus() throws Exception
	{
		
		 return CommonUtility.getLocator(AssetsPage_Data.get("Status"));
	}
	
    public By btnCreateDispatch() throws Exception{
		
		return CommonUtility.getLocator(AssetsPage_Data.get("CreateDispatchButton"));
	 
	}
    
    public By AssetHoldTxt() throws Exception{
		
 		return CommonUtility.getLocator(AssetsPage_Data.get("AssetHoldTxt"));
 	 
 	}
}
