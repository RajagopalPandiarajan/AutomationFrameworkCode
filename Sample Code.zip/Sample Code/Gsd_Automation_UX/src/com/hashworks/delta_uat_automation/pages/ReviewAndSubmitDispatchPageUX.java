package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class ReviewAndSubmitDispatchPageUX extends Pojo{

	

	

	public By txtserviceTypeUx() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ServiceTypeUx"));
		
}

	

	public By instructionNextButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("InstructionNextButton"));
		
}

	


	public By txtbilltoField() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("BilltoField"));
		
}


	public By defectiveComponentAddButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("DefectiveComponentAddButton"));
		
}
	

	public By manualPartLink() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ManualPartLink"));
		
}
	
	public By btnAutoPartLink() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("AutoPartLink"));
		
}
	
	public By btnScheduling() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("Scheduling"));
		
}
	

	public By PPIdNo() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("PPIdNo"));
		
}



	public By commodityNameDropDown() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("CommodityNameDropDown"));
		
}
	
	

	public By alertCheckBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("AlertCheckBox"));
		
}

	
	
	public By searchPPidImg() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("SearchPPidImg"));
		
	}
	
	

	public By btnplusIconforAddParts() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("PlusIconforAddParts"));
		
	}
	
	

	public By dispathchNo() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("DispathchNo"));
		
	}
	
	
	
	

	public By EndDispatchButton() throws Exception{
	
	return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("EndDispatchButton"));
	
}
	
	
	public By LastalertCheckBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("AlertCheckBoxLast"));
		
}
	
	public By btnLastDispatch() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("LastDispatch"));
		
}
	
	
	public By showMoreOptionsCheckBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ShowMoreOptionsCheckBox"));
		
	}

	

	public By BillableCheckbox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("BillableCheckbox"));
		
	}
	
	

	public By ReceiverList() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ReceiverList"));
		
	}
	

	public By InstructionNewButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("InstructionNewButton"));
		
	}
	
	

	public By InstructionType() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("InstructionType"));
		
	}
	

	public By InstructionsDeleteButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("InstructionsDeleteButton"));
		
	}
	
	
	

	public By txtBreakFixAtActivity() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("BreakFixAtActivity"));
		
	}
	
	

	public By lnkServiceReqNumber() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ServiceReqNumber"));
		
	}
	
	public By txtValidateLeftPane() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateLeftPane"));
		
	}
	
	public By txtValidateMiddlePane() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateMiddlePane"));
		
	}
	
	public By txtValidateRightPane() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateRightPane"));
		
	}
	
	public By txtValidateDisFirstName() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisFirstName"));
		
	}
	
	public By txtValidateDisLastName() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisLastName"));
		
	}
	
	public By txtValidateDisPhone() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisPhone"));
		
	}
	
	public By txtValidateDisPhoneExten() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisPhoneExten"));
		
	}
	
	public By txtValidateDisEmail() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisEmail"));
		
	}
	
	public By txtValidateContactAccord() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateContactAccord"));
		
	}
	
	public By txtValidateCustomerName() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateCustomerName"));
		
	}
	
	public By txtValidateDisAddressLine1() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisAddressLine1"));
		
	}
	
	public By txtValidateDisCountry() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateDisCountry"));
		
	}
	
	public By txtValidataDisPostal() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidataDisPostal"));
		
	}
	
	public By txtValidateCurrentEntitlement() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateCurrentEntitlement"));
		
	}
	
	public By txtValidateLocationCoverage() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateLocationCoverage"));
		
	}
	
	public By txtValidateServiceType() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateServiceType"));
		
	}
	
	public By txtValidateEntitlementStart() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateEntitlementStart"));
		
	}
	
	public By txtValidateEntitlementEnd() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateEntitlementEnd"));
		
	}
	
	public By txtValidateProductDesc() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateProductDesc"));
		
	}
	
	public By txtValidateReceiver() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateReceiver"));
		
	}
	
	public By txtValidateType() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateType"));
		
	}
	
	public By txtValidateInstruction() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateInstruction"));
		
	}
	
	public By txtValidateServiceOptions() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateServiceOptions"));
		
	}
	
	public By txtValidatePartFunction() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidatePartFunction"));
		
	}
	
	public By txtValidateSelectedParts() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateSelectedParts"));
		
	}
	
	public By txtValidateNewInstructionText() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewInstructionText"));
		
	}
	
	public By txtValidateNewInstructionReceiver() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewInstructionReceiver"));
		
	}
	
	public By txtValidateNewInstructionType() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewInstructionType"));
		
	}
	
	public By txtValidateNewInstructionCreated() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewInstructionCreated"));
		
	}
	
	public By txtValidateNewInstructionCreatedBy() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewInstructionCreatedBy"));
		
	}
	
	public By txtValidateNewStatus() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("ValidateNewStatus"));
		
	}
	
	public By btnDispatchOption() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPageUX_Data.get("DispatchOption"));
		
	}
	
	
	
}
