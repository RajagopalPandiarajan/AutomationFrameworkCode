package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class ResponsibilityPage extends Pojo {

	public ResponsibilityPage () {
	}
	
	public boolean validate() {
		return false;
	}
	
	
	public By lnkSiteMap() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("SiteMap"));
	}
	
	public By searchTextBox() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("AdministratorUser"));
	}
	
	public By lnkAdministratorUser() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("AdministratorUserLink"));
	}
	
	public By lnkEmployees() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("EmployeesLnk"));
	}
	
	public By txtUserID() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("UserID"));
	}
	
	public By txtUserName() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("UserName"));
	}
	
	public By btnUserIDButton() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("UserIDButton"));
	}
	
	public By btnRespButton() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("RespButton"));
	}
	
	public By btnRespRmvButton3() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("RespRmvButton3"));
	}
	
	public By txtRespSearchBox() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("RespSearchBox"));
	}
	
	public By btnRespRmvButton1() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("RespRmvButton1"));
	}
	
	public By btnRespAddRmvOkButton() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("RespAddRmvOkButton"));
	}
	
	public By btnFSDbutton() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("FSDbutton"));
	}
	
	public By btnFSDaddbutton1() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("FSDaddbutton1"));
	}
	
	public By btnFSDRmvButton3() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("FSDRmvButton3"));
	}
	
	public By btnFSDAddRmvOkButton() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("FSDAddRmvOkButton"));
	}
	
	public By FSDSearchTextBox() throws Exception
	{
		
		 return CommonUtility.getLocator(ResponsibilityPage_Data.get("FSDSearchTextBox"));
	}
	
	
}