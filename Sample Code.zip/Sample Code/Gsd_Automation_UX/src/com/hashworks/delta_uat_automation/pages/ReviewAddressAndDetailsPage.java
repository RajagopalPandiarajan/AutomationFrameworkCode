package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hashworks.delta_uat_automation.utility.CommonUtility;



public class ReviewAddressAndDetailsPage extends Pojo{
	
	
	public By getAddressLine1TextBox() throws Exception {
			
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("AddressLine1TextBox"));
		
	} 
	
	
	
	public By stateOrCountyDropDownTextBox() throws Exception {
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("StateOrCountyDropDownTextBox"));
		
	}
	
	
    public By getCityTextBox() throws Exception{
    	
    		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CityTextBox"));
    		
	}
    
    
    public By getCountryTextBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CountryTextBox"));
	 
	}
    
    public By getPostalCodeTextBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("PostalCodeTextBox"));
	 
	}
    

    public By getValidateButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("ValidateButton"));
	 
	}
    

    public By getAddressType() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("AddressTypeBar"));
	 
	}

    public By getOkButtonOfAddessValidation() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("OkButtonOfAddessValidation"));
	 
	}
    

    public By getDoNotUpdateAssetCheckBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("DoNotUpdateAssetCheckBox"));
	 
	}
    

    public By getNextButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NextButton"));
	 
	}
    

    public By getStateOrCountyDropDownArrow() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("StateOrCountyDropDownArrow"));
	 
	}
    
    

    public By getStateOrCountyTextBox() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("StateOrCounty"));
	 
	}

    public By getDropDownItem() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("DropDownItem"));
	 
	}
    

    
 public By txtRepeatReason() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("txtRepeatReason"));
	 
	}
    

    public By getCreateDispatchButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CreateDispatchButton"));
	 
	}
    

    public By getAgent() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("Agent"));
	 
	}
    
 public By CopyButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CopyButton"));
	}
 
 public By AddressValButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("AddressValButton"));
	}
 
 
 
 public By AddAddress() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("AddAddress"));
	}
 
 public By ProcessTypeText() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("ProcessTypeText"));
	}

 public By NextButtonName() throws Exception{
		
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NextButtonName"));
	}
    

//------------------------------------after dispatch creation--------------------------
 
 
 public By region() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("RegionTextbox"));


	}

	public By country() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CountryDropdown"));


	}

	public By timeZone() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("TimeZoneTextBox"));


	}

	public By status() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("StatusDropDown"));


	}

	public By subStatus() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("SubStatusDropDown"));


	}

	public By auditTrail() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("AuditTrailTab"));


	}

	public By oldvalueTable1() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("OldvalueTable1"));


	}

	public By newValueTable1() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NewValueTable1"));


	}

	public By oldvalueTable2() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("OldvalueTable2"));


	}

	public By newValueTable2() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NewValueTable2"));


	}

	public By oldvalueTable3() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("OldvalueTable3"));


	}

	public By newValueTable3() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NewValueTable3"));


	}

	public By oldvalueTable4() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("OldvalueTable4"));


	}

	public By newValueTable4() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("NewValueTable4"));


	}
	
	public By srLink() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("SRLink"));


	}



	public By deltaDispatch() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("DeltaDispatchTab"));


	}

	public By comment() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CommentSubTab"));


	}

	public By commentsToVendor() throws Exception
	{
		return CommonUtility.getLocator(ReviewAddressAndDetailsPage_Data.get("CommentsToVendor"));


	}





 

 
    

}
