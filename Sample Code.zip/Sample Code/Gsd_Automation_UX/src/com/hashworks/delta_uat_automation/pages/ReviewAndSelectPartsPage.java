package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class ReviewAndSelectPartsPage extends Pojo {


	public By getPartsNo() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("PartsNo"));
	 
	}
    


	public By getPartsToBeDispatchedNewButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("PartsToBeDispatchedNewButton"));
	 
	}




	

	public By getReviewButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("ReviewButton"));
	 
	}
	
	public By getManualButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("ManualButton"));
	 
	}
	
	
	public By getSelectButton() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("SelectButton"));
	 
	}
	
	
	public By getAddButtonUnderPartSelection() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSelectPartsPage_Data.get("AddButtonUnderPartSelection"));
	 
	}
	
	


}
