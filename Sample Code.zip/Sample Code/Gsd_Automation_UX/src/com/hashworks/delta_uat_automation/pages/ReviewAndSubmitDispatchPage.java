package com.hashworks.delta_uat_automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.hashworks.delta_uat_automation.utility.CommonUtility;

public class ReviewAndSubmitDispatchPage extends Pojo{
	
	

	public By nextButtonUnderSubmit() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("NextButton"));
		
}
	

	public By submitButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("Submit"));
		
}
	

	public By dpsNoUnderActivity() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("DpsNo"));
		
}
	

	public By regionUnderActivity() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("Region"));
		
}
	

	public By countryUnderActivity() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("Country"));
		
}
	
	
	
	
	public By getCurrentEntitlementTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CurrentEntitlementTextBox"));
		
}
 

	public By getLocationCoverageTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("LocationCoverageTextBox"));
		
}
	

	public By getPremierTypeTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PremierTypeTextBox"));
		
}
	

	public By serviceTypeTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ServiceType"));
		
}



	public By getAllServiceTypeOptions() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AllServiceTypeOptions"));
		
}


	public By getServiceOptionsList() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ServiceOptionsListTextBox"));
		
}
	
	public By getBillToTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("BillToTextBox"));
		
}
	
	public By getReferenceTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ReferenceTextBox"));
		
}
	

	public By getArrivalWindowStartTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ArrivalWindowStartTextBox"));
		
}
	
	

	public By getTimezoneTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("TimezoneTextBox"));
		
}
	
	
	public By getArrivalWindowEndTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ArrivalWindowEndTextBox"));
		
}
	

	public By getAddressLine1TextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AddressLine1TextBox"));
		
}
	
	

	public By getCityTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CityTextBox"));
		
}
	

	public By getCountryTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CountryTextBox"));
		
}
	

	public By getPostalCodeTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PostalCodeTextBox"));
		
}

	

	public By getStateOrCountTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("StateOrCountTextBox"));
		
}

	

	public By getFirstNameTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("FirstNameTextBox"));
		
}
	

	public By getLastNameTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("LastNameTextBox"));
		
}
	

	public By getPrimaryPhoneTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PrimaryPhoneTextBox"));
		
}
	
	

	public By getSecondaryPhoneTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("SecondaryPhoneTextBox"));
		
}


	public By getEmailTextBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("EmailTextBox"));
		
}
	

	public By getAddresslineLabel() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AddresslineLabel"));
		
}

	

	public By getservicetypeArrow() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("servicetypeArrow"));
		
}
	

	public By getPartsOnly() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PartsOnly"));
		
}
	
	public By getrepeatDispatch() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("repeatDispatch"));
		
}
	


	

	public By addParts() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AddParts"));
		
}	
	
	
	
	

	public By serviceTypeUx() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ServiceTypeUx"));
		
}

	


	//----------------------instruction elements----------------------------

		
	
	public By instructionCreatedByField() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionCreatedByField"));
		
}
	
	

	public By instructionNewButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionNewButton"));
		
}
	


	public By instructionDeleteButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionDeleteButton"));
		
}
	
	
	
	
	public By instructionNextButton() throws Exception{
	    	
			return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionNextButton"));
			
	}
		
		

		public By instructionRecieverField() throws Exception{
	    	
			return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionRecieverField"));
			
	}

		
		

		public By instructionType() throws Exception{
	    	
			return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionType"));
			
	}
		


		public By instructionField() throws Exception{
	    	
			return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionField"));
			
	}
		
		

	
	
	
	
	
	
	
	


	public By billtoField() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("InstructionNextButton"));
		
}


	public By defectiveComponentAddButton() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("DefectiveComponentAddButton"));
		
}
	

	public By manualPartLink() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("ManualPartLink"));
		
}
	

	public By PPIdNo() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PPIdNo"));
		
}



	public By commodityNameDropDown() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CommodityNameDropDown"));
		
}
	
	

	public By alertCheckBox() throws Exception{
    	
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlertCheckBox"));
		
}

	
	
	public By searchPPidImg() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("SearchPPidImg"));
		
	}
	
	

	public By plusIconforAddParts() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PlusIconforAddParts"));
		
	}
	
	

	public By dispathchNo() throws Exception{
		
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("DispathchNo"));
		
	}
	
	
	
	

	public By EndDispatchButton() throws Exception{
	
	return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("EndDispatchButton"));
	}
	
//----------------------------------------review and confirm fields----------------
	
	
	public By addressLine1TextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AddressLine1TextBox"));
	}

	public By cityTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CityTextBox"));
	}

	public By stateCountyTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("StateCountyTextBox"));
	}

 	public By countryTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CountryTextBox"));
	}

	public By postalCode() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PostalCodeTextBox"));
	}

	public By primaryContactFirstName() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PrimaryContactFirstName"));
	}

	public By primaryContactLastName() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PrimaryContactLastName"));
	}

	public By primaryContactPrimaryPhone() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PrimaryContactPrimaryPhone"));
	}

	public By primaryContactEmailTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PrimaryContactEmailTextBox"));
	}

	public By alternateContactFirstName() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactFirstName"));
	}

	public By alternateContactLastNameTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactLastNameTextBox"));
	}
	public By alternateContactPrimaryPhone() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactPrimaryPhone"));
	}

	public By alternateContactSecondaryPhone() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactSecondaryPhone"));
	}

	public By alternateContactEmail() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactEmail"));
	}

	public By currentEntitlementTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("CurrentEntitlementTextBox"));
	}

	public By locationCoverageTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("LocationCoverageTextBox"));
	}

	public By premierTypeTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("PremierTypeTextBox"));
	}

	public By systemClassificationTextBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("SystemClassificationTextBox"));
	}

	public By timezone() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("TimezoneTextBox"));
	}

	//-------------------------Alternate contact-------------------------------
	
	public By alternateContactCheeseBox() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("AlternateContactCheeseBox"));
	}
	
	public By OkBtnAlternateContact() throws Exception{
		return CommonUtility.getLocator(ReviewAndSubmitDispatchPage_Data.get("OkBtnAlternateContact"));
	}
	
	
	

	
	
	
}


